from flask import Blueprint, request, jsonify
from datetime import datetime
import random
import importlib
import config as _config_module          # imported as module so we can reload it
from app.db import get_db_connection
from app.utils import token_required, role_required

prescription_bp = Blueprint('prescription', __name__)

# 1. Submit Prescription
@prescription_bp.route('/prescription', methods=['POST'])
@token_required
@role_required(['provider'])
def submit_prescription():
    data = request.json or {}
    
    # Extract fields
    patient_id = data.get('patient_account_id')
    npi_number = data.get('npi_number')
    prod_nm = data.get('prod_nm')
    dosage_size = data.get('dosage_size')
    frequency = data.get('frequency')
    days_supply = data.get('days_supply')
    diagnosis = data.get('diagnosis')
    
    # Auto-generate current date for date_written
    date_written = datetime.now().strftime('%Y-%m-%d')

    # Basic validation
    if not all([patient_id, npi_number, prod_nm, dosage_size, frequency, days_supply, diagnosis]):
        return jsonify({'error': 'Missing required fields'}), 400

    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        # Generate unique RX Number
        cursor.execute("SELECT COUNT(*) FROM prescription")
        count = cursor.fetchone()[0] + 1
        date_str = datetime.now().strftime('%Y%m%d')
        rx_number = f"RX-{date_str}-{count:05d}"

        # Ensure patient exists
        cursor.execute("INSERT OR IGNORE INTO patient (patient_account_id) VALUES (?)", (patient_id,))
        
        # Ensure provider exists
        cursor.execute("INSERT OR IGNORE INTO provider (npi_number) VALUES (?)", (npi_number,))

        # Insert Prescription
        cursor.execute("""
            INSERT INTO prescription (rx_number, patient_account_id, npi_number, prod_nm, dosage_size, frequency, days_supply, rx_status, date_written)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'Submitted', ?)
        """, (rx_number, patient_id, npi_number, prod_nm, dosage_size, frequency, days_supply, date_written))

        # No separate RX tracking table — rely on prescription.rx_status and pbm_response/doctor_decision

        # Simulate PBM Processing (Randomized realistic data)
        simulate_pbm_processing(cursor, rx_number, prod_nm, diagnosis)

        conn.commit()
        return jsonify({'rx_number': rx_number, 'message': 'Prescription submitted successfully'})

    except Exception as e:
        conn.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        conn.close()




def simulate_pbm_processing(cursor, rx_number, drug, diagnosis):
    """
    Two-outcome PBM decision logic.
    Config is reloaded on every call so threshold changes in config.py
    take effect immediately without a server restart.
      - ai_confidence >= threshold  →  APPROVED  (auto-accepted by AI, no doctor review)
      - ai_confidence <  threshold  →  ESCALATED (awaits doctor review)
    """
    importlib.reload(_config_module)                     # force fresh read of config.py
    threshold = _config_module.Config.AUTO_APPROVE_THRESHOLD
    ai_conf   = round(random.uniform(0.20, 0.97), 2)    # range spans below & above any threshold
    auto_approved = ai_conf >= threshold

    if auto_approved:
        # ── High-confidence: fully covered, no manual review needed ──────────
        status     = 'APPROVED'
        alt        = None
        savings    = 0
        policy     = 'Fully covered'
        alt_policy = 'Fully covered'
    else:
        # ── Below threshold: escalate to doctor review ────────────────────────
        status     = 'ESCALATED'
        alt        = f"Preferred alternative for {drug}"
        savings    = random.randint(100, 2500)
        policy     = 'Prior auth required'
        alt_policy = 'Covered with copay'

    # ── Insert PBM Response ───────────────────────────────────────────────────
    cursor.execute("""
        INSERT INTO pbm_response (rx_number, status, ai_confidence, prescribed_drug, diagnosis, recommended_alt, cost_impact, safety_summary, policy_compliance)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'Reviewed by AI', 'Checked against formulary')
    """, (rx_number, status, ai_conf, drug, diagnosis, alt, savings))

    pbm_id = cursor.lastrowid

    # ── Cost Comparison ───────────────────────────────────────────────────────
    orig_price = random.randint(100, 3000)
    alt_price  = max(0, orig_price - savings)
    cursor.execute("""
        INSERT INTO pbm_cost_comparison (pbm_response_id, original_tier, original_price, original_copay, alternative_tier, alternative_price, alternative_copay, savings)
        VALUES (?, 'Tier 3', ?, ?, 'Tier 1', ?, ?, ?)
    """, (pbm_id, orig_price, orig_price * 0.2, alt_price, alt_price * 0.1, savings))

    # ── Safety ────────────────────────────────────────────────────────────────
    cursor.execute("""
        INSERT INTO pbm_safety (pbm_response_id, contraindications, interactions, monitoring)
        VALUES (?, 'None detected', 'Minimal interactions', 'Standard monitoring')
    """, (pbm_id,))

    # ── Policy ────────────────────────────────────────────────────────────────
    cursor.execute("""
        INSERT INTO pbm_policy (pbm_response_id, original_status, alternative_status)
        VALUES (?, ?, ?)
    """, (pbm_id, policy, alt_policy))

    # For our simplified flow we update prescription.rx_status above (Approved/ Pending)

    # ── Auto-approve when confidence >= threshold ─────────────────────────────
    if auto_approved:
        cursor.execute("""
            INSERT INTO doctor_decision (rx_number, status, reason)
            VALUES (?, 'ACCEPTED', NULL)
        """, (rx_number,))
        # Update prescription status to reflect auto-approval
        cursor.execute("""
            UPDATE prescription
            SET rx_status = 'Approved'
            WHERE rx_number = ?
        """, (rx_number,))
    else:
        # For escalated cases, set prescription to Pending for doctor review
        cursor.execute("""
            UPDATE prescription
            SET rx_status = 'Pending'
            WHERE rx_number = ?
        """, (rx_number,))



# 2. Track Status
@prescription_bp.route('/prescription/<rx_number>/status', methods=['GET'])
@token_required
def get_status(rx_number):
    conn = get_db_connection()
    cursor = conn.cursor()
    # Return simplified status composed from prescription, PBM response and doctor decision
    cursor.execute("SELECT rx_number, rx_status, date_written FROM prescription WHERE rx_number = ?", (rx_number,))
    pres = cursor.fetchone()

    if not pres:
        conn.close()
        return jsonify({'error': 'Prescription not found'}), 404

    # PBM Response
    cursor.execute("SELECT status AS pbm_status, ai_confidence, created_at FROM pbm_response WHERE rx_number = ?", (rx_number,))
    pbm = cursor.fetchone()

    # Doctor Decision
    cursor.execute("SELECT status AS decision_status, reason, created_at FROM doctor_decision WHERE rx_number = ?", (rx_number,))
    decision = cursor.fetchone()

    conn.close()

    # Derive a simple pipeline-style status to keep UI compatibility
    if not pbm:
        status = 'PROCESSING'
        agents_done = []
        agents_pending = ['clinical','financial','pbm']
        estimated_wait_s = 10
        created_at = pres['date_written']
    else:
        if pbm['pbm_status'] == 'ESCALATED' or (decision and not decision['decision_status']):
            status = 'ESCALATED'
            agents_done = ['clinical','financial','pbm']
            agents_pending = ['doctor']
        else:
            status = 'COMPLETED'
            agents_done = ['clinical','financial','pbm']
            agents_pending = []
        estimated_wait_s = 0
        created_at = pbm['created_at']

    response = {
        'rx_number': pres['rx_number'],
        'status': status,
        'prescription_status': pres['rx_status'],
        'date_written': pres['date_written'],
        'agents_done': agents_done,
        'agents_pending': agents_pending,
        'estimated_wait_s': estimated_wait_s,
        'created_at': created_at,
        'pbm_status': pbm['pbm_status'] if pbm else None,
        'ai_confidence': pbm['ai_confidence'] if pbm else None,
        'pbm_created_at': pbm['created_at'] if pbm else None,
        'doctor_decision': dict(decision) if decision else None
    }

    return jsonify(response)


# 3. Get PBM Results
@prescription_bp.route('/prescription/<rx_number>/result', methods=['GET'])
@token_required
@role_required(['doctor', 'provider'])
def get_results(rx_number):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # PBM Response
    cursor.execute("SELECT * FROM pbm_response WHERE rx_number = ?", (rx_number,))
    pbm = cursor.fetchone()
    
    if not pbm:
        conn.close()
        return jsonify({'pbm': None}) # Not ready yet
        
    pbm_id = pbm['id']
    
    # Sub-objects
    cursor.execute("SELECT * FROM pbm_cost_comparison WHERE pbm_response_id = ?", (pbm_id,))
    cost = cursor.fetchone()
    
    cursor.execute("SELECT * FROM pbm_safety WHERE pbm_response_id = ?", (pbm_id,))
    safety = cursor.fetchone()
    
    cursor.execute("SELECT * FROM pbm_policy WHERE pbm_response_id = ?", (pbm_id,))
    policy = cursor.fetchone()

    # Doctor Decision
    cursor.execute("SELECT * FROM doctor_decision WHERE rx_number = ?", (rx_number,))
    decision = cursor.fetchone()

    conn.close()
    
    return jsonify({
        'pbm': dict(pbm),
        'cost': dict(cost) if cost else None,
        'safety': dict(safety) if safety else None,
        'policy': dict(policy) if policy else None,
        'doctor_decision': dict(decision) if decision else None
    })


# 4. Submit Doctor Decision
@prescription_bp.route('/prescription/<rx_number>/decision', methods=['POST'])
@token_required
@role_required(['doctor'])
def submit_decision(rx_number):
    data = request.json or {}
    status = data.get('status')
    reason = data.get('reason')

    if status not in ['ACCEPTED', 'REJECTED', 'MODIFIED']:
        return jsonify({'error': 'Invalid status'}), 400

    if status in ['REJECTED', 'MODIFIED'] and not reason:
        return jsonify({'error': 'Reason is required for REJECTED or MODIFIED decisions'}), 400

    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("SELECT rx_number FROM prescription WHERE rx_number = ?", (rx_number,))
        if not cursor.fetchone():
            return jsonify({'error': 'Prescription not found'}), 404

        # Check if decision already exists
        cursor.execute("SELECT id FROM doctor_decision WHERE rx_number = ?", (rx_number,))
        if cursor.fetchone():
            return jsonify({'error': 'Decision already exists for this prescription'}), 400

        cursor.execute("""
            INSERT INTO doctor_decision (rx_number, status, reason)
            VALUES (?, ?, ?)
        """, (rx_number, status, reason))
        
        conn.commit()
        return jsonify({'message': 'Decision saved successfully'})
    except Exception as e:
        conn.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        conn.close()


# 5. Dashboard - All Prescriptions
@prescription_bp.route('/prescriptions', methods=['GET'])
@token_required
@role_required(['admin', 'doctor', 'provider'])
def list_prescriptions():
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT p.rx_number, p.patient_account_id, p.prod_nm, p.date_written,
               p.rx_status AS tracking_status,
               d.status   AS decision_status,
               pb.status  AS pbm_status
        FROM prescription p
        LEFT JOIN doctor_decision    d  ON p.rx_number = d.rx_number
        LEFT JOIN pbm_response       pb ON p.rx_number = pb.rx_number
        ORDER BY p.date_written DESC, p.rx_number DESC
    """)

    rows = cursor.fetchall()
    conn.close()

    return jsonify([dict(row) for row in rows])
