-- ============================================
-- Full Schema (SQLite)
-- ============================================

-- 1. Patient table
CREATE TABLE IF NOT EXISTS patient (
    patient_account_id  TEXT PRIMARY KEY
);

-- 2. Provider table
CREATE TABLE IF NOT EXISTS provider (
    npi_number  TEXT PRIMARY KEY
);

-- 3. Prescription table
CREATE TABLE IF NOT EXISTS prescription (
    rx_number           TEXT PRIMARY KEY,
    patient_account_id  TEXT NOT NULL,
    npi_number          TEXT NOT NULL,
    prod_nm             TEXT NOT NULL,
    dosage_size         TEXT NOT NULL,
    frequency           TEXT NOT NULL,
    days_supply         INTEGER NOT NULL,
    rx_status           TEXT NOT NULL CHECK (rx_status IN ('Submitted', 'Approved', 'Denied', 'Pending')),
    date_written        DATE NOT NULL,
    FOREIGN KEY (patient_account_id) REFERENCES patient (patient_account_id),
    FOREIGN KEY (npi_number) REFERENCES provider (npi_number)
);

-- 4. Doctor Decision table
CREATE TABLE IF NOT EXISTS doctor_decision (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    rx_number   TEXT NOT NULL,
    status      TEXT NOT NULL CHECK (status IN ('ACCEPTED', 'REJECTED', 'MODIFIED')),
    reason      TEXT,
    created_at  DATETIME NOT NULL DEFAULT (datetime('now')),

    -- reason is required when status = REJECTED or MODIFIED, nullable when ACCEPTED
    CHECK (
        (status = 'ACCEPTED' AND reason IS NULL)
        OR
        (status IN ('REJECTED', 'MODIFIED') AND reason IS NOT NULL)
    ),
    FOREIGN KEY (rx_number) REFERENCES prescription (rx_number)
);

-- 5. RX Status Tracking table (In-progress response: GET /rx/{rx_number}/status)
CREATE TABLE IF NOT EXISTS rx_status_tracking (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    rx_number         TEXT NOT NULL,
    status            TEXT NOT NULL CHECK (status IN ('PROCESSING', 'COMPLETED', 'FAILED', 'ESCALATED', 'PENDING_PA')),
    agents_done       TEXT NOT NULL DEFAULT '[]',       -- JSON array of strings e.g. '["clinical"]'
    agents_pending    TEXT NOT NULL DEFAULT '[]',       -- JSON array of strings e.g. '["financial","pbm"]'
    estimated_wait_s  INTEGER NOT NULL DEFAULT 0,       -- seconds
    created_at        DATETIME NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (rx_number) REFERENCES prescription (rx_number)
);

-- 6. PBM Response table (root + clinical_snapshot fields flattened)
CREATE TABLE IF NOT EXISTS pbm_response (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    rx_number           TEXT NOT NULL,
    status              TEXT NOT NULL CHECK (status IN ('ESCALATED', 'APPROVED', 'DENIED', 'PENDING_REVIEW')),
    ai_confidence       REAL NOT NULL CHECK (ai_confidence >= 0.0 AND ai_confidence <= 1.0),  -- 0.0 to 1.0
    prescribed_drug     TEXT NOT NULL,
    diagnosis           TEXT NOT NULL,
    recommended_alt     TEXT,
    cost_impact         REAL NOT NULL DEFAULT 0,        -- savings amount
    safety_summary      TEXT NOT NULL,
    policy_compliance   TEXT NOT NULL,
    created_at          DATETIME NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (rx_number) REFERENCES prescription (rx_number)
);

-- 7. PBM Cost Comparison (nested sub-object of PBM Response)
CREATE TABLE IF NOT EXISTS pbm_cost_comparison (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    pbm_response_id     INTEGER NOT NULL,
    original_tier       TEXT NOT NULL,
    original_price      REAL NOT NULL,
    original_copay      REAL NOT NULL,
    alternative_tier    TEXT NOT NULL,
    alternative_price   REAL NOT NULL,
    alternative_copay   REAL NOT NULL,
    savings             REAL NOT NULL,
    FOREIGN KEY (pbm_response_id) REFERENCES pbm_response (id)
);

-- 8. PBM Safety (nested sub-object of PBM Response)
CREATE TABLE IF NOT EXISTS pbm_safety (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    pbm_response_id     INTEGER NOT NULL,
    contraindications   TEXT NOT NULL,
    interactions        TEXT NOT NULL,
    monitoring          TEXT NOT NULL,
    FOREIGN KEY (pbm_response_id) REFERENCES pbm_response (id)
);

-- 9. PBM Policy (nested sub-object of PBM Response)
CREATE TABLE IF NOT EXISTS pbm_policy (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    pbm_response_id     INTEGER NOT NULL,
    original_status     TEXT NOT NULL,
    alternative_status  TEXT NOT NULL,
    FOREIGN KEY (pbm_response_id) REFERENCES pbm_response (id)
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_prescription_patient ON prescription (patient_account_id);
CREATE INDEX IF NOT EXISTS idx_prescription_provider ON prescription (npi_number);
CREATE INDEX IF NOT EXISTS idx_doctor_decision_rx ON doctor_decision (rx_number);
CREATE INDEX IF NOT EXISTS idx_rx_status_tracking_rx ON rx_status_tracking (rx_number);
CREATE INDEX IF NOT EXISTS idx_pbm_response_rx ON pbm_response (rx_number);
CREATE INDEX IF NOT EXISTS idx_pbm_cost_comparison_resp ON pbm_cost_comparison (pbm_response_id);
CREATE INDEX IF NOT EXISTS idx_pbm_safety_resp ON pbm_safety (pbm_response_id);
CREATE INDEX IF NOT EXISTS idx_pbm_policy_resp ON pbm_policy (pbm_response_id);
