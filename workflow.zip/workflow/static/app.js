// ============================================
// PBM Prescription Workflow — Client Logic
// ============================================

const state = {
  currentView: 'submit',
  pollInterval: null
};

function init() {
  window.addEventListener('hashchange', handleRoute);
  
  document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      const view = item.getAttribute('data-view');
      window.location.hash = view;
    });
  });

  document.getElementById('prescription-form').addEventListener('submit', handleFormSubmit);
  document.getElementById('track-btn').addEventListener('click', handleTrackSearch);
  document.getElementById('results-btn').addEventListener('click', handleResultsSearch);
  
  document.getElementById('track-search').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') handleTrackSearch();
  });
  document.getElementById('results-search').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') handleResultsSearch();
  });

  if (!window.location.hash) {
    window.location.hash = 'submit';
  } else {
    handleRoute();
  }
}

function handleRoute() {
  const hash = window.location.hash.substring(1) || 'submit';
  const validViews = ['submit', 'track', 'results', 'dashboard'];
  
  if (validViews.includes(hash)) {
    switchView(hash);
  }
}

function switchView(viewId) {
  state.currentView = viewId;
  
  if (state.pollInterval) {
    clearInterval(state.pollInterval);
    state.pollInterval = null;
  }

  document.querySelectorAll('.nav-item').forEach(item => {
    item.classList.toggle('active', item.getAttribute('data-view') === viewId);
  });

  document.querySelectorAll('.view').forEach(view => {
    view.classList.toggle('active', view.id === `view-${viewId}`);
  });

  if (viewId === 'dashboard') {
    loadDashboard();
  }
}

async function handleFormSubmit(e) {
  e.preventDefault();
  const btn = document.getElementById('submit-btn');
  btn.disabled = true;
  btn.textContent = 'Submitting...';

  const formData = {
    patient_account_id: document.getElementById('patient_id').value,
    npi_number: document.getElementById('npi_number').value,
    prod_nm: document.getElementById('prod_nm').value,
    dosage_size: document.getElementById('dosage_size').value,
    frequency: document.getElementById('frequency').value,
    days_supply: document.getElementById('days_supply').value,
    diagnosis: document.getElementById('diagnosis').value
  };

  try {
    const response = await fetch('/api/prescription', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData)
    });

    const data = await response.json();
    
    if (response.ok) {
      showToast('Prescription submitted successfully');
      document.getElementById('modal-rx-number').textContent = data.rx_number;
      document.getElementById('success-modal').classList.add('show');
      document.getElementById('prescription-form').reset();
    } else {
      showToast(data.error || 'Failed to submit prescription');
    }
  } catch (error) {
    showToast('Network error while submitting');
    console.error(error);
  } finally {
    btn.disabled = false;
    btn.textContent = 'Submit to PBM';
  }
}

function copyRxNumber() {
  const rxNumber = document.getElementById('modal-rx-number').textContent;
  navigator.clipboard.writeText(rxNumber).then(() => {
    showToast('RX Number copied to clipboard');
  });
}

function closeModal() {
  document.getElementById('success-modal').classList.remove('show');
}

function goTrackFromModal() {
  const rxNumber = document.getElementById('modal-rx-number').textContent;
  closeModal();
  document.getElementById('track-search').value = rxNumber;
  window.location.hash = 'track';
  setTimeout(() => handleTrackSearch(), 100);
}

async function handleTrackSearch() {
  const rxNumber = document.getElementById('track-search').value.trim();
  if (!rxNumber) {
    showToast('Please enter an RX Number');
    return;
  }

  const contentArea = document.getElementById('track-content');
  contentArea.innerHTML = '<div class="loading-state">Fetching status...</div>';

  try {
    const response = await fetch(`/api/prescription/${rxNumber}/status`);
    const data = await response.json();

    if (response.ok) {
      renderTrackStatus(data);
      if (data.status === 'PROCESSING') {
        if (state.pollInterval) clearInterval(state.pollInterval);
        state.pollInterval = setInterval(() => pollTrackStatus(rxNumber), 5000);
      }
    } else {
      contentArea.innerHTML = `<div class="empty-state"><p>${data.error || 'Prescription not found'}</p></div>`;
    }
  } catch (error) {
    showToast('Network error while fetching status');
    contentArea.innerHTML = `<div class="empty-state"><p>Failed to load status. Please try again.</p></div>`;
  }
}

async function pollTrackStatus(rxNumber) {
  if (state.currentView !== 'track') {
    clearInterval(state.pollInterval);
    return;
  }
  try {
    const response = await fetch(`/api/prescription/${rxNumber}/status`);
    if (response.ok) {
      const data = await response.json();
      renderTrackStatus(data);
      if (data.status !== 'PROCESSING') {
        clearInterval(state.pollInterval);
        showToast('Prescription processing completed');
      }
    }
  } catch (error) {
    console.error('Polling error:', error);
  }
}

function renderTrackStatus(data) {
  const contentArea = document.getElementById('track-content');
  let agentsDone = typeof data.agents_done === 'string' ? JSON.parse(data.agents_done || '[]') : (data.agents_done || []);
  let agentsPending = typeof data.agents_pending === 'string' ? JSON.parse(data.agents_pending || '[]') : (data.agents_pending || []);

  const agentsDoneHtml = agentsDone.map(a => `<span class="agent-tag done">${a}</span>`).join('');
  const agentsPendingHtml = agentsPending.map(a => `<span class="agent-tag pending">${a}</span>`).join('');

  const isCompleted = ['COMPLETED', 'APPROVED', 'DENIED', 'ESCALATED', 'PENDING_PA'].includes(data.status);
  const hasDecision = data.doctor_decision !== null;
  
  let pbmStepClass = '';
  if (isCompleted) pbmStepClass = data.status === 'FAILED' ? 'failed' : 'done';
  else if (data.status === 'PROCESSING') pbmStepClass = 'active';

  contentArea.innerHTML = `
    <div class="card" id="track-pdf-area">
      <div class="page-header-actions" style="margin-bottom: 20px;">
        <div class="card-title" style="margin-bottom: 0; border: none;">
          Status for RX: <strong>${data.rx_number}</strong>
        </div>
        <button class="btn" onclick="downloadPDF('track-pdf-area', 'Status_${data.rx_number}')">
          Download PDF
        </button>
      </div>

      <div class="info-grid">
        <div class="info-item">
          <strong>Current Status:</strong> <span class="badge badge-${data.status.toLowerCase()}">${data.status}</span>
        </div>
        <div class="info-item">
          <strong>Estimated Wait Time:</strong> ${data.status === 'PROCESSING' ? `${data.estimated_wait_s} seconds` : '—'}
        </div>
        <div class="info-item" style="grid-column: span 2;">
          <strong>Last Updated:</strong> ${new Date(data.created_at).toLocaleString()}
        </div>
      </div>

      <div class="pipeline">
        <div class="pipeline-step done">Submitted</div>
        <div class="pipeline-step ${data.status === 'PROCESSING' ? 'active' : 'done'}">Processing</div>
        <div class="pipeline-step ${pbmStepClass}">PBM Review</div>
        <div class="pipeline-step ${hasDecision ? 'done' : (isCompleted ? 'active' : '')}">Doctor Decision</div>
        <div class="pipeline-step ${hasDecision ? 'done' : ''}">Complete</div>
      </div>

      <div style="margin-top: 20px;">
        <h4 style="margin-bottom: 10px;">Agent Workflow Progress</h4>
        <div class="info-grid">
          <div class="info-item">
            <div style="color: var(--text-muted); font-size: 0.8rem; margin-bottom: 5px;">COMPLETED AGENTS</div>
            <div>${agentsDoneHtml || 'None yet'}</div>
          </div>
          <div class="info-item">
            <div style="color: var(--text-muted); font-size: 0.8rem; margin-bottom: 5px;">PENDING AGENTS</div>
            <div>${agentsPendingHtml || 'None pending'}</div>
          </div>
        </div>
      </div>
      
      ${isCompleted && !hasDecision ? `
        <div style="text-align: center; margin-top: 20px;">
          <button class="btn btn-primary" onclick="goToResults('${data.rx_number}')">
            View PBM Results & Make Decision
          </button>
        </div>
      ` : ''}
    </div>
  `;
}

function goToResults(rxNumber) {
  document.getElementById('results-search').value = rxNumber;
  window.location.hash = 'results';
  setTimeout(() => handleResultsSearch(), 100);
}

async function handleResultsSearch() {
  const rxNumber = document.getElementById('results-search').value.trim();
  if (!rxNumber) {
    showToast('Please enter an RX Number');
    return;
  }

  const contentArea = document.getElementById('results-content');
  contentArea.innerHTML = '<div class="loading-state">Loading PBM results...</div>';

  try {
    const response = await fetch(`/api/prescription/${rxNumber}/result`);
    const data = await response.json();

    if (response.ok) {
      if (!data.pbm) {
         contentArea.innerHTML = `
          <div class="empty-state">
            <p>PBM results not available yet. The prescription may still be processing.</p>
            <button class="btn" style="margin-top: 10px" onclick="document.getElementById('track-search').value='${rxNumber}'; window.location.hash='track'; setTimeout(handleTrackSearch, 100);">Check Status</button>
          </div>`;
         return;
      }
      renderPbmResults(rxNumber, data);
    } else {
      contentArea.innerHTML = `<div class="empty-state"><p>${data.error || 'Failed to load results'}</p></div>`;
    }
  } catch (error) {
    showToast('Network error while fetching results');
    contentArea.innerHTML = `<div class="empty-state"><p>Failed to load results. Please try again.</p></div>`;
  }
}

function renderPbmResults(rxNumber, data) {
  const contentArea = document.getElementById('results-content');
  const pbm = data.pbm;
  const cost = data.cost || {};
  const safety = data.safety || {};
  const policy = data.policy || {};
  const existingDecision = data.doctor_decision;
  const confPercent = Math.round(pbm.ai_confidence * 100);

  let html = `
    <div class="card" id="results-pdf-area">
      <div class="page-header-actions" style="margin-bottom: 20px;">
        <div class="card-title" style="margin-bottom: 0; border: none;">
          PBM Analysis Report: <strong>${rxNumber}</strong>
        </div>
        <button class="btn" onclick="downloadPDF('results-pdf-area', 'PBM_Report_${rxNumber}')">
          Download PDF
        </button>
      </div>

      <div class="info-grid">
        <div class="info-item" style="grid-column: span 2;">
          <strong>AI Confidence Score:</strong> ${confPercent}%
        </div>
        <div class="info-item">
          <strong>PBM Status:</strong> <span class="badge badge-${pbm.status.toLowerCase()}">${pbm.status}</span>
        </div>
        <div class="info-item">
          <strong>Prescribed Drug:</strong> ${pbm.prescribed_drug}
        </div>
        <div class="info-item">
          <strong>Diagnosis:</strong> ${pbm.diagnosis}
        </div>
        <div class="info-item">
          <strong>Recommended Alternative:</strong> ${pbm.recommended_alt || 'None Recommended'}
        </div>
      </div>

      <div style="margin-top: 20px;">
        <h4>Cost Analysis</h4>
        <table class="compare-table">
          <thead>
            <tr><th></th><th>Original</th><th>Alternative</th></tr>
          </thead>
          <tbody>
            <tr><td><strong>Tier</strong></td><td>${cost.original_tier || '—'}</td><td>${cost.alternative_tier || '—'}</td></tr>
            <tr><td><strong>Total Price</strong></td><td>$${cost.original_price || 0}</td><td>$${cost.alternative_price || 0}</td></tr>
            <tr><td><strong>Patient Copay</strong></td><td>$${cost.original_copay || 0}</td><td>$${cost.alternative_copay || 0}</td></tr>
            <tr style="background-color: #f8f9fa;"><td><strong>Potential Savings</strong></td><td colspan="2">$${cost.savings || 0}</td></tr>
          </tbody>
        </table>
      </div>

      <div style="margin-top: 20px;">
        <h4>Clinical & Policy</h4>
        <div class="info-grid" style="margin-top: 10px;">
          <div class="info-item">
            <div style="color: var(--text-muted); font-size: 0.8rem;">SAFETY SUMMARY</div>
            <div>${pbm.safety_summary}</div>
            <hr style="border: 0; border-top: 1px solid var(--border-color); margin: 8px 0;">
            <div style="font-size: 0.9rem;">
              <strong>Contraindications:</strong> ${safety.contraindications || 'None'}<br>
              <strong>Interactions:</strong> ${safety.interactions || 'None'}<br>
              <strong>Monitoring:</strong> ${safety.monitoring || 'None'}
            </div>
          </div>
          <div class="info-item">
            <div style="color: var(--text-muted); font-size: 0.8rem;">POLICY COMPLIANCE</div>
            <div>${pbm.policy_compliance}</div>
            <hr style="border: 0; border-top: 1px solid var(--border-color); margin: 8px 0;">
            <div style="font-size: 0.9rem;">
              <strong>Original Status:</strong> ${policy.original_status || '—'}<br>
              <strong>Alt Status:</strong> ${policy.alternative_status || '—'}
            </div>
          </div>
        </div>
      </div>

      <div style="margin-top: 30px; border-top: 1px solid var(--border-color); padding-top: 20px;">
        <h4>Doctor Clinical Decision</h4>
        ${existingDecision ? `
          <div style="margin-top: 10px; padding: 15px; background: #f8f9fa; border: 1px solid var(--border-color);">
            <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
              <span class="badge badge-${existingDecision.status.toLowerCase()}">${existingDecision.status}</span>
              <span style="color: var(--text-muted); font-size: 0.9rem;">Recorded on ${new Date(existingDecision.created_at).toLocaleString()}</span>
            </div>
            ${existingDecision.reason ? `<div><strong>Reasoning:</strong> ${existingDecision.reason}</div>` : ''}
          </div>
        ` : `
          <div style="margin-top: 10px;">
            <div style="display: flex; gap: 10px; margin-bottom: 10px;">
              <button class="btn btn-success" onclick="showDecisionReason('ACCEPTED', '${rxNumber}')">Accept Original</button>
              <button class="btn btn-warning" onclick="showDecisionReason('MODIFIED', '${rxNumber}')">Modify</button>
              <button class="btn btn-danger" onclick="showDecisionReason('REJECTED', '${rxNumber}')">Reject</button>
            </div>
            
            <div class="decision-reason" id="decision-reason-container">
              <div class="form-group">
                <label id="decision-reason-label">Reasoning (Required)</label>
                <textarea id="decision-reason-input" placeholder="Enter clinical reasoning..."></textarea>
              </div>
              <div style="display: flex; gap: 10px;">
                <button class="btn btn-primary" id="submit-decision-btn">Submit Decision</button>
                <button class="btn" onclick="cancelDecision()">Cancel</button>
              </div>
            </div>
          </div>
        `}
      </div>
    </div>
  `;
  contentArea.innerHTML = html;
}

let pendingDecisionStatus = null;
let pendingDecisionRx = null;

function showDecisionReason(status, rxNumber) {
  pendingDecisionStatus = status;
  pendingDecisionRx = rxNumber;
  
  const container = document.getElementById('decision-reason-container');
  const input = document.getElementById('decision-reason-input');
  const label = document.getElementById('decision-reason-label');
  
  if (status === 'ACCEPTED') {
    submitDecision();
    return;
  }
  
  label.textContent = `Reasoning for ${status} (Required)`;
  container.classList.add('show');
  input.focus();
  document.getElementById('submit-decision-btn').onclick = submitDecision;
}

function cancelDecision() {
  document.getElementById('decision-reason-container').classList.remove('show');
  document.getElementById('decision-reason-input').value = '';
  pendingDecisionStatus = null;
}

async function submitDecision() {
  const reasonInput = document.getElementById('decision-reason-input');
  const reason = reasonInput ? reasonInput.value.trim() : '';
  
  if ((pendingDecisionStatus === 'REJECTED' || pendingDecisionStatus === 'MODIFIED') && !reason) {
    showToast('Please provide a reason for this decision');
    if (reasonInput) reasonInput.focus();
    return;
  }

  try {
    const response = await fetch(`/api/prescription/${pendingDecisionRx}/decision`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        status: pendingDecisionStatus,
        reason: reason || null
      })
    });

    const data = await response.json();
    
    if (response.ok) {
      showToast('Decision saved successfully');
      handleResultsSearch();
    } else {
      showToast(data.error || 'Failed to save decision');
    }
  } catch (error) {
    showToast('Network error while saving decision');
  }
}

async function loadDashboard() {
  const contentArea = document.getElementById('dashboard-content');
  const statsArea = document.getElementById('dashboard-stats');
  
  try {
    const response = await fetch('/api/prescriptions');
    const data = await response.json();
    
    if (response.ok) {
      const total = data.length;
      const completed = data.filter(r => ['COMPLETED', 'APPROVED', 'DENIED'].includes(r.tracking_status)).length;
      const processing = data.filter(r => r.tracking_status === 'PROCESSING').length;
      const hasDecision = data.filter(r => r.decision_status !== null).length;
      
      statsArea.innerHTML = `
        <div class="stats-row">
          <div class="stat-card">
            <div class="stat-value">${total}</div>
            <div style="font-size: 0.8rem; color: var(--text-muted);">Total RXs</div>
          </div>
          <div class="stat-card">
            <div class="stat-value">${completed}</div>
            <div style="font-size: 0.8rem; color: var(--text-muted);">PBM Completed</div>
          </div>
          <div class="stat-card">
            <div class="stat-value">${processing}</div>
            <div style="font-size: 0.8rem; color: var(--text-muted);">Processing</div>
          </div>
          <div class="stat-card">
            <div class="stat-value">${hasDecision}</div>
            <div style="font-size: 0.8rem; color: var(--text-muted);">Decisions Made</div>
          </div>
        </div>
      `;

      if (data.length === 0) {
        contentArea.innerHTML = `<div class="empty-state"><p>No prescriptions found.</p></div>`;
        return;
      }

      let tableHtml = `
        <div style="overflow-x: auto;">
          <table class="data-table">
            <thead>
              <tr>
                <th>RX Number</th>
                <th>Patient</th>
                <th>Drug</th>
                <th>Date Written</th>
                <th>PBM Tracking</th>
                <th>Doctor Decision</th>
              </tr>
            </thead>
            <tbody>
      `;

      data.forEach(row => {
        const trackingBadge = `<span class="badge badge-${row.tracking_status.toLowerCase()}">${row.tracking_status}</span>`;
        const decisionBadge = row.decision_status 
          ? `<span class="badge badge-${row.decision_status.toLowerCase()}">${row.decision_status}</span>` 
          : '<span style="color: var(--text-muted); font-size: 0.8rem;">Pending</span>';
        
        tableHtml += `
          <tr style="cursor: pointer;" onclick="goToResults('${row.rx_number}')">
            <td>${row.rx_number}</td>
            <td>${row.patient_account_id}</td>
            <td>${row.prod_nm}</td>
            <td>${row.date_written}</td>
            <td>${trackingBadge}</td>
            <td>${decisionBadge}</td>
          </tr>
        `;
      });

      tableHtml += `</tbody></table></div>`;
      contentArea.innerHTML = tableHtml;
    } else {
      contentArea.innerHTML = `<div class="empty-state"><p>Failed to load dashboard</p></div>`;
    }
  } catch (error) {
    contentArea.innerHTML = `<div class="empty-state"><p>Network error loading dashboard</p></div>`;
  }
}

function showToast(message) {
  const container = document.getElementById('toast-container');
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 4000);
}

function downloadPDF(elementId, filename) {
  const element = document.getElementById(elementId);
  if (!element) return;
  const opt = {
    margin: 10,
    filename: `${filename}.pdf`,
    image: { type: 'jpeg', quality: 0.98 },
    html2canvas: { scale: 2 },
    jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
  };
  showToast('Generating PDF...');
  html2pdf().set(opt).from(element).save().then(() => {
    showToast('PDF downloaded');
  }).catch(err => {
    console.error(err);
    showToast('Error generating PDF');
  });
}

document.addEventListener('DOMContentLoaded', init);
