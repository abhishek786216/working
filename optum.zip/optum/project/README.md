# Multi-Agent Prior Authorization System

## Run Commands

Install dependencies:

```bash
pip install -r requirements.txt
```

Smoke-test the FastAPI app import:

```bash
python -c "import app.main; print('import-ok')"
```

The database bootstrap includes demo rows so you can test submission, lookup, approval, and PDF export locally.

Run the backend API:

```bash
python -m uvicorn app.main:app --reload
```

Run that command from the project root directory, not from `app/`. If you are using a virtual environment on Windows, activate it first, for example:

```powershell
.\.venv\Scripts\Activate.ps1
```

Run the Streamlit dashboard:

```bash
python -m streamlit run dashboard/dashboard.py
```

Run that command from the project root directory, not from `app/` or the parent `optum/` folder. If you are using a virtual environment on Windows, activate it first, for example:

## Workflow Image

![PBM workflow](docs/pbm_workflow.svg)

## Manual Test Data

Use these examples to test the workflow by hand.

### 1. Submit a new prescription

```json
{
	"patient_id": "PAT-1001",
	"drug_name": "Amoxicillin",
	"dosage": "500mg",
	"prescribing_doctor": "DOC-1001",
	"notes": "Take after meals"
}
```

### 2. Save orchestrator decision

```json
{
	"decision": "NEEDS_REVIEW",
	"confidence_score": 0.82,
	"reasoning": "Please verify the dose and duration before approval.",
	"agent_breakdown": {
		"policy_agent": "covered",
		"clinical_agent": "review required",
		"financial_agent": "acceptable",
		"past_decisions_agent": "similar cases were modified"
	}
}
```

### 3. Doctor response examples

Accept:

```json
{
	"action": "accept"
}
```

Reject:

```json
{
	"action": "reject",
	"description": "Drug is not covered under this plan."
}
```

Modify:

```json
{
	"action": "modify",
	"description": "Reduce dosage to 250mg twice daily."
}
```

### 4. Sample existing rows in the local database

These are useful for quick GET checks right now:

```text
RX-41D62C  ->  TRK-20260619164102-0A63742FA5
RX-8A34B9  ->  TRK-20260619164102-2C1FEB34C1
RX-001     ->  TRK-20260619164102-5AD81ADCBD
RX-002     ->  TRK-20260619164102-E741054674
RX-003     ->  TRK-20260619164102-44F1C50ADA
```

Use them with:

```bash
GET /prescriptions/<tracking_id>
GET /prescriptions/<tracking_id>/pdf
```
