"""Streamlit dashboard for pharmacist intake and doctor review workflows."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

import requests
import streamlit as st


API_BASE_URL = "http://127.0.0.1:8000"


st.set_page_config(page_title="PBM System", page_icon="💊", layout="wide")

API_BASE_URL = st.sidebar.text_input("API Base URL", value=API_BASE_URL)


def api_get(path: str) -> requests.Response:
    """Send a GET request to the backend API."""

    return requests.get(f"{API_BASE_URL}{path}", timeout=20)


def api_post(path: str, payload: Dict[str, Any]) -> requests.Response:
    """Send a POST request to the backend API."""

    return requests.post(f"{API_BASE_URL}{path}", json=payload, timeout=20)


def render_prescription_summary(record: Dict[str, Any]) -> None:
    """Render a compact, readable summary of a prescription record."""

    st.json(
        {
            "prescription_id": record.get("prescription_id"),
            "tracking_id": record.get("tracking_id"),
            "status": record.get("status"),
            "decision": record.get("decision"),
            "confidence_score": record.get("confidence_score"),
            "reasoning": record.get("reasoning"),
            "doctor_response_action": record.get("doctor_response_action"),
            "doctor_response_description": record.get("doctor_response_description")
            or record.get("modification_description"),
        }
    )


def submit_pharmacist_form() -> None:
    """Render the pharmacist submission and lookup workflow."""

    st.subheader("Pharmacist View")
    with st.form("prescription_submission_form"):
        patient_id = st.text_input("Patient ID")
        drug_name = st.text_input("Drug Name")
        dosage = st.text_input("Dosage")
        prescribing_doctor = st.text_input("Prescribing Doctor")
        notes = st.text_area("Notes", height=120)
        submitted = st.form_submit_button("Submit Prescription")

    if submitted:
        payload = {
            "patient_id": patient_id,
            "drug_name": drug_name,
            "dosage": dosage,
            "prescribing_doctor": prescribing_doctor,
            "notes": notes,
        }
        try:
            response = api_post("/prescriptions/submit", payload)
            if response.ok:
                data = response.json()
                st.success(data["message"])
                st.write(
                    {
                        "prescription_id": data["prescription_id"],
                        "tracking_id": data["tracking_id"],
                        "status": data["status"],
                    }
                )
            else:
                st.error(response.json().get("detail", "Submission failed"))
        except requests.RequestException as exc:
            st.error(f"Unable to reach the API: {exc}")

    st.divider()
    st.markdown("### Status Lookup")
    tracking_id = st.text_input("Tracking ID", key="pharmacist_tracking_id")
    lookup_col, pdf_col = st.columns(2)

    if lookup_col.button("Retrieve Status", key="retrieve_status_button") and tracking_id.strip():
        try:
            response = api_get(f"/prescriptions/{tracking_id.strip()}")
            if response.ok:
                st.session_state["lookup_record"] = response.json()["prescription"]
            else:
                st.error(response.json().get("detail", "Prescription not found"))
        except requests.RequestException as exc:
            st.error(f"Unable to reach the API: {exc}")

    if "lookup_record" in st.session_state:
        render_prescription_summary(st.session_state["lookup_record"])

        try:
            pdf_response = api_get(f"/prescriptions/{st.session_state['lookup_record']['tracking_id']}/pdf")
            if pdf_response.ok:
                pdf_col.download_button(
                    label="Download PDF",
                    data=pdf_response.content,
                    file_name=f"{st.session_state['lookup_record']['prescription_id']}.pdf",
                    mime="application/pdf",
                    key="download_pdf_button",
                )
            else:
                st.error(pdf_response.json().get("detail", "PDF generation failed"))
        except requests.RequestException as exc:
            st.error(f"Unable to reach the API: {exc}")


def submit_doctor_response(prescription_id: str, action: str, description: Optional[str] = None) -> None:
    """Call the approval endpoint for a doctor action."""

    payload: Dict[str, Any] = {"action": action}
    if description is not None:
        payload["description"] = description

    try:
        response = api_post(f"/prescriptions/{prescription_id}/doctor-response", payload)
        if response.ok:
            st.success(f"{action.title()} saved for {prescription_id}")
            st.session_state.pop(f"doctor_action_{prescription_id}", None)
            st.session_state.pop(f"doctor_description_{prescription_id}", None)
            st.rerun()
        else:
            st.error(response.json().get("detail", "Unable to save doctor response"))
    except requests.RequestException as exc:
        st.error(f"Unable to reach the API: {exc}")


def render_doctor_review_card(record: Dict[str, Any]) -> None:
    """Render one prescription review card with action buttons."""

    prescription_id = record["prescription_id"]
    st.markdown(f"#### {prescription_id}")
    st.write(
        {
            "patient_id": record.get("patient_id"),
            "drug_name": record.get("drug_name"),
            "dosage": record.get("dosage"),
            "status": record.get("status"),
            "decision": record.get("decision"),
            "confidence_score": record.get("confidence_score"),
        }
    )
    if record.get("reasoning"):
        st.info(record["reasoning"])

    action_key = f"doctor_action_{prescription_id}"
    description_key = f"doctor_description_{prescription_id}"

    button_cols = st.columns(3)
    if button_cols[0].button("Accept", key=f"accept_{prescription_id}"):
        submit_doctor_response(prescription_id, "accept")
    if button_cols[1].button("Reject", key=f"reject_{prescription_id}"):
        st.session_state[action_key] = "reject"
    if button_cols[2].button("Modify", key=f"modify_{prescription_id}"):
        st.session_state[action_key] = "modify"

    pending_action = st.session_state.get(action_key)
    if pending_action in {"reject", "modify"}:
        description = st.text_area(
            f"{pending_action.title()} description",
            key=description_key,
            value=st.session_state.get(description_key, ""),
            height=100,
        )
        if st.button(f"Submit {pending_action.title()}", key=f"submit_{pending_action}_{prescription_id}"):
            submit_doctor_response(prescription_id, pending_action, description)


def render_doctor_view() -> None:
    """Render the doctor review queue and workflow actions."""

    st.subheader("Doctor View")
    try:
        response = api_get("/prescriptions/pending")
        if not response.ok:
            st.error(response.json().get("detail", "Unable to load pending prescriptions"))
            return
    except requests.RequestException as exc:
        st.error(f"Unable to reach the API: {exc}")
        return

    records: List[Dict[str, Any]] = response.json().get("items", [])
    if not records:
        st.info("No pending prescriptions right now.")
        return

    for record in records:
        with st.container():
            render_doctor_review_card(record)


st.markdown(
    """
    <style>
        .block-container { padding-top: 2rem; }
    </style>
    """,
    unsafe_allow_html=True,
)

st.title("PBM Prescription Portal")
st.caption("Pharmacist intake, orchestrator review, doctor response, and PDF export in one workflow.")

pharmacist_tab, doctor_tab = st.tabs(["Pharmacist View", "Doctor View"])

with pharmacist_tab:
    submit_pharmacist_form()

with doctor_tab:
    render_doctor_view()