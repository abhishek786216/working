"""Simple audit logger for prescription state transitions."""

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional

from app.db.schema import current_timestamp, get_connection, row_to_dict


def log_state_transition(
	prescription_id: str,
	previous_status: Optional[str],
	new_status: str,
	event_type: str,
	details: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
	"""Record a status change and the context that caused it."""

	connection = get_connection()
	try:
		connection.execute(
			"""
			INSERT INTO audit_log (
				prescription_id,
				event_type,
				previous_status,
				new_status,
				details,
				created_at
			)
			VALUES (?, ?, ?, ?, ?, ?)
			""",
			(
				prescription_id,
				event_type,
				previous_status,
				new_status,
				json.dumps(details or {}, ensure_ascii=False),
				current_timestamp(),
			),
		)
		connection.commit()

		cursor = connection.execute(
			"""
			SELECT *
			FROM audit_log
			WHERE prescription_id = ?
			ORDER BY id DESC
			LIMIT 1
			""",
			(prescription_id,),
		)
		return row_to_dict(cursor.fetchone()) or {}
	finally:
		connection.close()


def get_audit_trail(prescription_id: Optional[str] = None) -> List[Dict[str, Any]]:
	"""Return the audit trail for one prescription or the full log."""

	connection = get_connection()
	try:
		if prescription_id:
			cursor = connection.execute(
				"SELECT * FROM audit_log WHERE prescription_id = ? ORDER BY id DESC",
				(prescription_id,),
			)
		else:
			cursor = connection.execute("SELECT * FROM audit_log ORDER BY id DESC")
		return [row_to_dict(row) for row in cursor.fetchall() if row is not None]
	finally:
		connection.close()
