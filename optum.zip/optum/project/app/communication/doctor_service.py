"""FastAPI routes for pharmacist intake and prescription status lookup."""

from __future__ import annotations

import io
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from fastapi import APIRouter, HTTPException, status
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from app.audit.logger import log_state_transition
from app.communication.pdf_generator import build_prescription_pdf_bytes
from app.db.schema import (
    current_timestamp,
    fetch_prescription_by_tracking_id,
    generate_tracking_id,
    get_connection,
    list_pending_prescriptions,
)

router = APIRouter(tags=["prescriptions"])


class PrescriptionSubmissionRequest(BaseModel):
    """Request payload accepted from the pharmacist-facing intake form."""

    patient_id: str = Field(..., min_length=1)
    drug_name: str = Field(..., min_length=1)
    dosage: str = Field(..., min_length=1)
    prescribing_doctor: str = Field(..., min_length=1)
    notes: Optional[str] = Field(default=None)


class PrescriptionSubmissionResponse(BaseModel):
    """Response returned immediately after a prescription is stored."""

    prescription_id: str
    tracking_id: str
    status: str
    message: str


def _clean_text(value: Optional[str], field_name: str) -> str:
    """Trim user input and reject empty values for required text fields."""

    if value is None:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"{field_name} is required")

    cleaned_value = value.strip()
    if not cleaned_value:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"{field_name} is required")
    return cleaned_value


def generate_prescription_id() -> str:
    """Generate a collision-safe prescription identifier."""

    return f"RX-{datetime.now(timezone.utc):%Y%m%d%H%M%S}-{uuid.uuid4().hex[:8].upper()}"


def _insert_prescription_record(payload: PrescriptionSubmissionRequest) -> Dict[str, Any]:
    """Persist a new prescription submission and return the inserted record."""

    prescription_id = generate_prescription_id()
    tracking_id = generate_tracking_id()
    submitted_at = current_timestamp()
    notes = payload.notes.strip() if payload.notes and payload.notes.strip() else None

    connection = get_connection()
    try:
        connection.execute(
            """
            INSERT INTO prescriptions (
                prescription_id,
                tracking_id,
                patient_id,
                drug_name,
                dosage,
                prescribing_doctor,
                doctor_id,
                notes,
                status,
                submitted_at,
                updated_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                prescription_id,
                tracking_id,
                _clean_text(payload.patient_id, "patient_id"),
                _clean_text(payload.drug_name, "drug_name"),
                _clean_text(payload.dosage, "dosage"),
                _clean_text(payload.prescribing_doctor, "prescribing_doctor"),
                _clean_text(payload.prescribing_doctor, "prescribing_doctor"),
                notes,
                "SUBMITTED",
                submitted_at,
                submitted_at,
            ),
        )
        connection.commit()

        stored_record = fetch_prescription_by_tracking_id(tracking_id)
        if stored_record is None:
            raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to persist prescription")

        log_state_transition(
            prescription_id=prescription_id,
            previous_status=None,
            new_status="SUBMITTED",
            event_type="submission",
            details={
                "tracking_id": tracking_id,
                "patient_id": payload.patient_id,
                "drug_name": payload.drug_name,
            },
        )

        return stored_record
    finally:
        connection.close()


@router.post("/prescriptions/submit", response_model=PrescriptionSubmissionResponse)
def submit_prescription(request: PrescriptionSubmissionRequest) -> PrescriptionSubmissionResponse:
    """Accept a new pharmacist submission and store it as a queued prescription."""

    stored_record = _insert_prescription_record(request)
    return PrescriptionSubmissionResponse(
        prescription_id=stored_record["prescription_id"],
        tracking_id=stored_record["tracking_id"],
        status=stored_record["status"],
        message="Prescription submitted successfully",
    )


@router.get("/prescriptions/pending")
def get_pending_prescriptions() -> Dict[str, Any]:
    """Return prescriptions that still need pharmacist or doctor attention."""

    return {"items": list_pending_prescriptions()}


@router.get("/prescriptions/{tracking_id}/pdf")
def download_prescription_pdf(tracking_id: str) -> StreamingResponse:
    """Render the stored prescription and decision trail into a downloadable PDF."""

    record = fetch_prescription_by_tracking_id(tracking_id)
    if record is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Prescription not found")

    pdf_bytes = build_prescription_pdf_bytes(record)
    filename = f"{record['prescription_id']}_{tracking_id}.pdf"
    return StreamingResponse(
        io.BytesIO(pdf_bytes),
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.get("/prescriptions/{tracking_id}")
def get_prescription_by_tracking_id_endpoint(tracking_id: str) -> Dict[str, Any]:
    """Return the full stored prescription record for a tracking identifier."""

    record = fetch_prescription_by_tracking_id(tracking_id)
    if record is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Prescription not found")

    return {"prescription": record}
