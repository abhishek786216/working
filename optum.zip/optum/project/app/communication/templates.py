"""Reusable notification templates for dashboard and messaging surfaces."""

from __future__ import annotations

from typing import Dict


def _message(subject: str, body: str) -> Dict[str, str]:
	"""Return a normalized message payload for notifications."""

	return {"subject": subject, "body": body}


def notify_pharmacist_submission(prescription_id: str, tracking_id: str) -> Dict[str, str]:
	"""Tell the pharmacist that the submission was accepted into the queue."""

	return _message(
		subject=f"Prescription {prescription_id} submitted",
		body=(
			f"Prescription {prescription_id} was submitted successfully. "
			f"Use tracking ID {tracking_id} to check status, retrieve the PDF, or review later updates."
		),
	)


def notify_doctor_review_needed(prescription_id: str, reasoning: str) -> Dict[str, str]:
	"""Tell the doctor that a prescription needs manual review."""

	return _message(
		subject=f"Review needed for {prescription_id}",
		body=(
			f"Prescription {prescription_id} requires review. "
			f"Orchestrator reasoning: {reasoning.strip()}."
		),
	)


def notify_decision_accepted(prescription_id: str) -> Dict[str, str]:
	"""Notify stakeholders that the prescription has been accepted."""

	return _message(
		subject=f"Prescription {prescription_id} accepted",
		body=f"Prescription {prescription_id} has been accepted and moved forward in the workflow.",
	)


def notify_decision_rejected(prescription_id: str, description: str) -> Dict[str, str]:
	"""Notify stakeholders that the prescription has been rejected."""

	return _message(
		subject=f"Prescription {prescription_id} rejected",
		body=(
			f"Prescription {prescription_id} has been rejected. "
			f"Reason: {description.strip()}."
		),
	)


def notify_decision_modified(prescription_id: str, description: str) -> Dict[str, str]:
	"""Notify stakeholders that the prescription requires modification."""

	return _message(
		subject=f"Prescription {prescription_id} modified",
		body=(
			f"Prescription {prescription_id} needs modification before completion. "
			f"Requested change: {description.strip()}."
		),
	)
