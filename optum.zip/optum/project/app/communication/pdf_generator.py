"""PDF generation helpers for prescription records."""

from __future__ import annotations

from io import BytesIO
from typing import Any, Dict, Iterable, Tuple

from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle


def _format_value(value: Any) -> str:
	"""Normalize empty values so the PDF stays readable."""

	if value is None:
		return "-"
	if isinstance(value, str):
		stripped_value = value.strip()
		return stripped_value if stripped_value else "-"
	return str(value)


def _rows_from_record(record: Dict[str, Any]) -> Iterable[Tuple[str, str]]:
	"""Yield the display rows that should appear in the generated PDF."""

	ordered_fields = [
		("Prescription ID", record.get("prescription_id")),
		("Tracking ID", record.get("tracking_id")),
		("Patient ID", record.get("patient_id")),
		("Drug Name", record.get("drug_name")),
		("Dosage", record.get("dosage")),
		("Prescribing Doctor", record.get("prescribing_doctor") or record.get("doctor_id")),
		("Notes", record.get("notes")),
		("Status", record.get("status")),
		("Decision", record.get("decision")),
		("Confidence Score", record.get("confidence_score")),
		("Reasoning", record.get("reasoning")),
		("Doctor Action", record.get("doctor_response_action")),
		("Doctor Response", record.get("doctor_response_description") or record.get("modification_description")),
		("Submitted At", record.get("submitted_at")),
		("Updated At", record.get("updated_at")),
		("Orchestrator Decision At", record.get("orchestrator_decided_at")),
		("Doctor Responded At", record.get("doctor_responded_at")),
	]

	for label, value in ordered_fields:
		yield label, _format_value(value)


def build_prescription_pdf_bytes(record: Dict[str, Any]) -> bytes:
	"""Create a downloadable PDF summary for a stored prescription record."""

	buffer = BytesIO()
	document = SimpleDocTemplate(
		buffer,
		pagesize=letter,
		rightMargin=0.6 * inch,
		leftMargin=0.6 * inch,
		topMargin=0.75 * inch,
		bottomMargin=0.6 * inch,
	)

	styles = getSampleStyleSheet()
	title_style = ParagraphStyle(
		"PrescriptionTitle",
		parent=styles["Title"],
		textColor=colors.HexColor("#1F4E79"),
		fontSize=20,
		leading=24,
		spaceAfter=12,
	)
	subtitle_style = ParagraphStyle(
		"PrescriptionSubtitle",
		parent=styles["BodyText"],
		textColor=colors.HexColor("#555555"),
		fontSize=10,
		leading=13,
		spaceAfter=14,
	)

	story = [
		Paragraph("PBM Prescription Summary", title_style),
		Paragraph(
			"This PDF captures the intake record, orchestrator result, and doctor response history for the selected prescription.",
			subtitle_style,
		),
		Spacer(1, 0.15 * inch),
	]

	table_data = [["Field", "Value"]]
	table_data.extend([[label, value] for label, value in _rows_from_record(record)])

	summary_table = Table(table_data, colWidths=[2.15 * inch, 4.85 * inch], repeatRows=1)
	summary_table.setStyle(
		TableStyle(
			[
				("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1F4E79")),
				("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
				("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
				("FONTSIZE", (0, 0), (-1, -1), 9),
				("LEADING", (0, 0), (-1, -1), 11),
				("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.whitesmoke, colors.HexColor("#EAF2F8")]),
				("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#B8C6D1")),
				("VALIGN", (0, 0), (-1, -1), "TOP"),
				("LEFTPADDING", (0, 0), (-1, -1), 8),
				("RIGHTPADDING", (0, 0), (-1, -1), 8),
				("TOPPADDING", (0, 0), (-1, -1), 6),
				("BOTTOMPADDING", (0, 0), (-1, -1), 6),
			]
		)
	)
	story.append(summary_table)

	document.build(story)
	pdf_bytes = buffer.getvalue()
	buffer.close()
	return pdf_bytes
