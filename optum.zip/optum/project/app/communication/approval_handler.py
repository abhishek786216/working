"""FastAPI routes for orchestrator decisions and doctor approval responses."""

from __future__ import annotations

from typing import Any, Dict, Literal, Optional

from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel, Field

from app.audit.logger import log_state_transition
from app.db.schema import (
    current_timestamp,
    fetch_prescription_by_prescription_id,
    update_prescription_fields,
)
from app.feedback_db.acceptance_store import log_doctor_response

router = APIRouter(tags=["approvals"])


class OrchestratorDecisionPayload(BaseModel):
    """Decision object returned by the orchestrator layer."""

    decision: str = Field(..., min_length=1)
    confidence_score: float = Field(..., ge=0.0, le=1.0)
    reasoning: str = Field(..., min_length=1)
    agent_breakdown: Optional[Dict[str, Any]] = None


class DoctorResponseRequest(BaseModel):
    """Doctor-facing response payload for accept, reject, and modify actions."""

    action: Literal["accept", "reject", "modify"]
    description: Optional[str] = None


def _normalize_status(decision: str) -> str:
    """Map the orchestrator decision to the stored prescription status."""

    normalized_decision = decision.strip().upper()
    status_map = {
        "APPROVED": "APPROVED",
        "REJECTED": "REJECTED",
        "NEEDS_REVIEW": "NEEDS_REVIEW",
    }
    return status_map.get(normalized_decision, normalized_decision)


def _require_prescription_or_404(prescription_id: str) -> Dict[str, Any]:
    """Load a prescription row and fail fast if it does not exist."""

    record = fetch_prescription_by_prescription_id(prescription_id)
    if record is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Prescription not found")
    return record


@router.post("/prescriptions/{prescription_id}/orchestrator-decision")
def save_orchestrator_decision(
    prescription_id: str,
    payload: OrchestratorDecisionPayload,
) -> Dict[str, Any]:
    """Persist the orchestrator output on the underlying prescription record."""

    existing_record = _require_prescription_or_404(prescription_id)
    previous_status = existing_record.get("status")
    new_status = _normalize_status(payload.decision)

    updated_record = update_prescription_fields(
        prescription_id,
        {
            "decision": payload.decision.strip().upper(),
            "confidence_score": payload.confidence_score,
            "reasoning": payload.reasoning.strip(),
            "status": new_status,
            "orchestrator_decided_at": current_timestamp(),
        },
    )

    log_state_transition(
        prescription_id=prescription_id,
        previous_status=previous_status,
        new_status=new_status,
        event_type="orchestrator_decision",
        details={
            "decision": payload.decision,
            "confidence_score": payload.confidence_score,
            "reasoning": payload.reasoning,
            "agent_breakdown": payload.agent_breakdown,
        },
    )

    return {"prescription": updated_record}


@router.post("/prescriptions/{prescription_id}/doctor-response")
def record_doctor_response(
    prescription_id: str,
    payload: DoctorResponseRequest,
) -> Dict[str, Any]:
    """Store the pharmacist or doctor response for the submitted prescription."""

    existing_record = _require_prescription_or_404(prescription_id)
    previous_status = existing_record.get("status")

    description = payload.description.strip() if payload.description else None
    if payload.action in {"reject", "modify"} and not description:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="description is required when action is reject or modify",
        )

    action_status = {
        "accept": "ACCEPTED",
        "reject": "REJECTED",
        "modify": "MODIFIED",
    }[payload.action]

    update_fields: Dict[str, Any] = {
        "doctor_response_action": payload.action,
        "doctor_response_description": description,
        "doctor_responded_at": current_timestamp(),
        "status": action_status,
    }
    if payload.action == "modify":
        update_fields["modification_description"] = description

    updated_record = update_prescription_fields(prescription_id, update_fields)

    log_doctor_response(
        prescription_id=prescription_id,
        action=payload.action,
        description=description,
    )
    log_state_transition(
        prescription_id=prescription_id,
        previous_status=previous_status,
        new_status=action_status,
        event_type="doctor_response",
        details={
            "action": payload.action,
            "description": description,
        },
    )

    return {"prescription": updated_record}