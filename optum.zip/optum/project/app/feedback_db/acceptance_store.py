"""Persistence helpers for doctor acceptance, rejection, and modification events."""

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional

from app.db.schema import current_timestamp, get_connection, row_to_dict


def log_doctor_response(
	prescription_id: str,
	action: str,
	description: Optional[str] = None,
) -> Dict[str, Any]:
	"""Write a doctor response row to the dedicated response log table."""

	connection = get_connection()
	try:
		connection.execute(
			"""
			INSERT INTO doctor_response_log (
				prescription_id,
				action,
				description,
				created_at
			)
			VALUES (?, ?, ?, ?)
			""",
			(prescription_id, action, description, current_timestamp()),
		)
		connection.commit()

		cursor = connection.execute(
			"""
			SELECT *
			FROM doctor_response_log
			WHERE prescription_id = ?
			ORDER BY id DESC
			LIMIT 1
			""",
			(prescription_id,),
		)
		return row_to_dict(cursor.fetchone()) or {}
	finally:
		connection.close()


def get_doctor_responses(prescription_id: Optional[str] = None) -> List[Dict[str, Any]]:
	"""Return response log rows for one prescription or for the whole table."""

	connection = get_connection()
	try:
		if prescription_id:
			cursor = connection.execute(
				"SELECT * FROM doctor_response_log WHERE prescription_id = ? ORDER BY id DESC",
				(prescription_id,),
			)
		else:
			cursor = connection.execute("SELECT * FROM doctor_response_log ORDER BY id DESC")
		return [row_to_dict(row) for row in cursor.fetchall() if row is not None]
	finally:
		connection.close()
