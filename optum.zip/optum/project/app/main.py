from fastapi import FastAPI

from app.communication.doctor_service import router as doctor_router
from app.communication.approval_handler import router as approval_router

app = FastAPI()

app.include_router(doctor_router)
app.include_router(approval_router)

@app.get("/")
def home():
    return {"message": "API Running"}
