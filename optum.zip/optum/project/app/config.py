class Settings:
    APP_NAME = "PA Multi-Agent System"

settings = Settings()
