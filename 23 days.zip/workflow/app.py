import os
import sqlite3
import random
from datetime import datetime
import jwt
from functools import wraps
from werkzeug.security import check_password_hash, generate_password_hash
from datetime import timedelta
from flask import Flask, jsonify, request, send_from_directory



app = Flask(__name__, static_url_path='/static', static_folder='static')
DB_PATH = 'database/doctor_decisions.db'


app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'super-secret-key-change-this-to-a-long-random-value')


def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None

        if 'Authorization' in request.headers:
            parts = request.headers['Authorization'].split(" ")
            if len(parts) == 2:
                token = parts[1]

        if not token:
            return jsonify({'error': 'Token missing'}), 401

        try:
            data = jwt.decode(token, app.config['SECRET_KEY'], algorithms=['HS256'])
            request.user = data
        except Exception:
            return jsonify({'error': 'Invalid/Expired token'}), 401

        return f(*args, **kwargs)
    return decorated



def role_required(roles):
    def wrapper(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            if request.user['role'] not in roles:
                return jsonify({'error': 'Forbidden'}), 403
            return f(*args, **kwargs)
        return decorated
    return wrapper


def verify_password(user, password):
    """
    Supports real Werkzeug hashes and a demo fallback for placeholder seed hashes.
    """
    password_hash = user['password_hash']

    if password_hash and '$hash' in password_hash:
        return password == 'password123'

    return check_password_hash(password_hash, password)


@app.route('/api/register', methods=['POST'])
def register():
    data = request.json or {}
    username = (data.get('username') or '').strip()
    password = data.get('password') or ''
    role = (data.get('role') or 'provider').strip().lower()

    if not username or not password:
        return jsonify({'error': 'Username and password are required'}), 400

    if len(password) < 6:
        return jsonify({'error': 'Password must be at least 6 characters'}), 400

    allowed_roles = {'provider', 'doctor'}
    if role not in allowed_roles:
        return jsonify({'error': 'Role must be provider or doctor'}), 400

    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("SELECT id FROM users WHERE username=?", (username,))
        if cursor.fetchone():
            return jsonify({'error': 'Username already exists'}), 409

        cursor.execute(
            "INSERT INTO users (username, password_hash, role, is_active) VALUES (?, ?, ?, 1)",
            (username, generate_password_hash(password), role)
        )
        conn.commit()
        return jsonify({'message': 'Registration successful. Please login.', 'role': role}), 201
    except Exception as e:
        conn.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        conn.close()


@app.route('/api/login', methods=['POST'])
def login():
    data = request.json or {}
    username = data.get('username')
    password = data.get('password')

    if not username or not password:
        return jsonify({'error': 'Username and password are required'}), 400

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM users WHERE username=? AND is_active=1", (username,))
    user = cursor.fetchone()
    conn.close()

    if not user:
        return jsonify({'error': 'Invalid credentials'}), 401

    if not verify_password(user, password):
        return jsonify({'error': 'Invalid credentials'}), 401

    token = jwt.encode({
        'id': user['id'],
        'role': user['role'],
        'exp': datetime.utcnow() + timedelta(hours=2)
    }, app.config['SECRET_KEY'], algorithm='HS256')

    return jsonify({"token": token, "role": user["role"]})

def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

# ── Serve Frontend ──
@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

# ── API Routes ──

# 1. Submit Prescription
@app.route('/api/prescription', methods=['POST'])
@token_required
@role_required(['provider'])
def submit_prescription():
    data = request.json or {}
    
    # Extract fields
    patient_id = data.get('patient_account_id')
    npi_number = data.get('npi_number')
    prod_nm = data.get('prod_nm')
    dosage_size = data.get('dosage_size')
    frequency = data.get('frequency')
    days_supply = data.get('days_supply')
    diagnosis = data.get('diagnosis')
    
    # Auto-generate current date for date_written
    date_written = datetime.now().strftime('%Y-%m-%d')

    # Basic validation
    if not all([patient_id, npi_number, prod_nm, dosage_size, frequency, days_supply, diagnosis]):
        return jsonify({'error': 'Missing required fields'}), 400

    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        # Generate unique RX Number
        cursor.execute("SELECT COUNT(*) FROM prescription")
        count = cursor.fetchone()[0] + 1
        date_str = datetime.now().strftime('%Y%m%d')
        rx_number = f"RX-{date_str}-{count:05d}"

        # Ensure patient exists
        cursor.execute("INSERT OR IGNORE INTO patient (patient_account_id) VALUES (?)", (patient_id,))
        
        # Ensure provider exists
        cursor.execute("INSERT OR IGNORE INTO provider (npi_number) VALUES (?)", (npi_number,))

        # Insert Prescription
        cursor.execute("""
            INSERT INTO prescription (rx_number, patient_account_id, npi_number, prod_nm, dosage_size, frequency, days_supply, rx_status, date_written)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'Submitted', ?)
        """, (rx_number, patient_id, npi_number, prod_nm, dosage_size, frequency, days_supply, date_written))

        # Insert initial Tracking status (Processing)
        cursor.execute("""
            INSERT INTO rx_status_tracking (rx_number, status, agents_done, agents_pending, estimated_wait_s)
            VALUES (?, 'PROCESSING', '[]', '["clinical", "financial", "pbm"]', 10)
        """, (rx_number,))

        # Simulate PBM Processing (Randomized realistic data)
        # We'll create the PBM data immediately but the frontend will poll for it
        simulate_pbm_processing(cursor, rx_number, prod_nm, diagnosis)

        conn.commit()
        return jsonify({'rx_number': rx_number, 'message': 'Prescription submitted successfully'})

    except Exception as e:
        conn.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        conn.close()

def simulate_pbm_processing(cursor, rx_number, drug, diagnosis):
    # Determine PBM status based on random AI confidence
    ai_conf = round(random.uniform(0.45, 0.97), 2)
    if ai_conf >= 0.82:
        status = 'APPROVED'
        alt = None
        savings = 0
        policy = 'Fully covered'
        alt_policy = 'Fully covered'
    elif ai_conf >= 0.62:
        status = 'ESCALATED'
        alt = f"Preferred generic for {drug}"
        savings = random.randint(100, 1000)
        policy = 'Prior auth required'
        alt_policy = 'Covered with copay'
    else:
        status = 'DENIED'
        alt = f"Therapeutic alternative to {drug}"
        savings = random.randint(500, 2500)
        policy = 'Not covered'
        alt_policy = 'Fully covered'

    # Insert PBM Response
    cursor.execute("""
        INSERT INTO pbm_response (rx_number, status, ai_confidence, prescribed_drug, diagnosis, recommended_alt, cost_impact, safety_summary, policy_compliance)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'Reviewed by AI', 'Checked against formulary')
    """, (rx_number, status, ai_conf, drug, diagnosis, alt, savings))


    # system needed change
    
    pbm_id = cursor.lastrowid

    # Insert Cost Comparison
    orig_price = random.randint(100, 3000)
    alt_price = max(0, orig_price - savings)
    cursor.execute("""
        INSERT INTO pbm_cost_comparison (pbm_response_id, original_tier, original_price, original_copay, alternative_tier, alternative_price, alternative_copay, savings)
        VALUES (?, 'Tier 3', ?, ?, 'Tier 1', ?, ?, ?)
    """, (pbm_id, orig_price, orig_price * 0.2, alt_price, alt_price * 0.1, savings))

    # Insert Safety
    cursor.execute("""
        INSERT INTO pbm_safety (pbm_response_id, contraindications, interactions, monitoring)
        VALUES (?, 'None detected', 'Minimal interactions', 'Standard monitoring')
    """, (pbm_id,))

    # Insert Policy
    cursor.execute("""
        INSERT INTO pbm_policy (pbm_response_id, original_status, alternative_status)
        VALUES (?, ?, ?)
    """, (pbm_id, policy, alt_policy))

    # Update tracking to COMPLETED
    cursor.execute("""
        UPDATE rx_status_tracking 
        SET status = 'COMPLETED', agents_done = '["clinical", "financial", "pbm"]', agents_pending = '[]', estimated_wait_s = 0
        WHERE rx_number = ?
    """, (rx_number,))


# 2. Track Status
@app.route('/api/prescription/<rx_number>/status', methods=['GET'])
@token_required
def get_status(rx_number):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("SELECT * FROM rx_status_tracking WHERE rx_number = ?", (rx_number,))
    tracking = cursor.fetchone()
    
    if not tracking:
        conn.close()
        return jsonify({'error': 'Prescription not found'}), 404

    # Check if a doctor decision exists
    cursor.execute("SELECT status FROM doctor_decision WHERE rx_number = ?", (rx_number,))
    decision = cursor.fetchone()

    conn.close()
    
    data = dict(tracking)
    data['doctor_decision'] = decision['status'] if decision else None
    
    return jsonify(data)


# 3. Get PBM Results
@app.route('/api/prescription/<rx_number>/result', methods=['GET'])
@token_required
@role_required(['doctor', 'provider'])
def get_results(rx_number):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # PBM Response
    cursor.execute("SELECT * FROM pbm_response WHERE rx_number = ?", (rx_number,))
    pbm = cursor.fetchone()
    
    if not pbm:
        conn.close()
        return jsonify({'pbm': None}) # Not ready yet
        
    pbm_id = pbm['id']
    
    # Sub-objects
    cursor.execute("SELECT * FROM pbm_cost_comparison WHERE pbm_response_id = ?", (pbm_id,))
    cost = cursor.fetchone()
    
    cursor.execute("SELECT * FROM pbm_safety WHERE pbm_response_id = ?", (pbm_id,))
    safety = cursor.fetchone()
    
    cursor.execute("SELECT * FROM pbm_policy WHERE pbm_response_id = ?", (pbm_id,))
    policy = cursor.fetchone()

    # Doctor Decision
    cursor.execute("SELECT * FROM doctor_decision WHERE rx_number = ?", (rx_number,))
    decision = cursor.fetchone()

    conn.close()
    
    return jsonify({
        'pbm': dict(pbm),
        'cost': dict(cost) if cost else None,
        'safety': dict(safety) if safety else None,
        'policy': dict(policy) if policy else None,
        'doctor_decision': dict(decision) if decision else None
    })


# 4. Submit Doctor Decision
@app.route('/api/prescription/<rx_number>/decision', methods=['POST'])
@token_required
@role_required(['doctor'])
def submit_decision(rx_number):
    data = request.json or {}
    status = data.get('status')
    reason = data.get('reason')

    if status not in ['ACCEPTED', 'REJECTED', 'MODIFIED']:
        return jsonify({'error': 'Invalid status'}), 400

    if status in ['REJECTED', 'MODIFIED'] and not reason:
        return jsonify({'error': 'Reason is required for REJECTED or MODIFIED decisions'}), 400

    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("SELECT rx_number FROM prescription WHERE rx_number = ?", (rx_number,))
        if not cursor.fetchone():
            return jsonify({'error': 'Prescription not found'}), 404

        # Check if decision already exists
        cursor.execute("SELECT id FROM doctor_decision WHERE rx_number = ?", (rx_number,))
        if cursor.fetchone():
            return jsonify({'error': 'Decision already exists for this prescription'}), 400

        cursor.execute("""
            INSERT INTO doctor_decision (rx_number, status, reason)
            VALUES (?, ?, ?)
        """, (rx_number, status, reason))
        
        conn.commit()
        return jsonify({'message': 'Decision saved successfully'})
    except Exception as e:
        conn.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        conn.close()


# 5. Dashboard - All Prescriptions
@app.route('/api/prescriptions', methods=['GET'])
@token_required
@role_required(['admin', 'doctor', 'provider'])
def list_prescriptions():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT p.rx_number, p.patient_account_id, p.prod_nm, p.date_written, 
               t.status as tracking_status, d.status as decision_status
        FROM prescription p
        LEFT JOIN rx_status_tracking t ON p.rx_number = t.rx_number
        LEFT JOIN doctor_decision d ON p.rx_number = d.rx_number
        ORDER BY p.date_written DESC, p.rx_number DESC
    """)
    
    rows = cursor.fetchall()
    conn.close()
    
    return jsonify([dict(row) for row in rows])

if __name__ == '__main__':
    # Initialize DB if it doesn't exist
    if not os.path.exists(DB_PATH):
        print(f"Warning: Database {DB_PATH} not found. Please run setup_db.py first.")
    
    app.run(debug=True, port=5000)
