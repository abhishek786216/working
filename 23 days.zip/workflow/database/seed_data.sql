-- ============================================
-- Seed Data
-- ============================================

-- Patients (6 patients)
INSERT INTO patient (patient_account_id) VALUES
    ('P001'), ('P002'), ('P003'), ('P004'), ('P005'), ('P006');

-- Providers (4 providers)
INSERT INTO provider (npi_number) VALUES
    ('1234567890'), ('2345678901'), ('3456789012'), ('4567890123');

-- Prescriptions (10 records)
INSERT INTO prescription (rx_number, patient_account_id, npi_number, prod_nm, dosage_size, frequency, days_supply, rx_status, date_written) VALUES
    ('10001', 'P001', '1234567890', 'Paracetamol',    '500 mg',  'BID',  5,  'Submitted', '2026-06-20'),
    ('10002', 'P002', '2345678901', 'Amoxicillin',    '250 mg',  'TID',  7,  'Submitted', '2026-06-19'),
    ('10003', 'P003', '1234567890', 'Metformin',      '850 mg',  'BID',  30, 'Submitted', '2026-06-18'),
    ('10004', 'P001', '3456789012', 'Lisinopril',     '10 mg',   'QD',   30, 'Submitted', '2026-06-17'),
    ('10005', 'P004', '2345678901', 'Cetirizine',     '10 mg',   'QD',   14, 'Submitted', '2026-06-16'),
    ('10006', 'P005', '4567890123', 'Atorvastatin',   '20 mg',   'QD',   30, 'Submitted', '2026-06-15'),
    ('10007', 'P002', '1234567890', 'Omeprazole',     '20 mg',   'QD',   14, 'Submitted', '2026-06-14'),
    ('10008', 'P006', '3456789012', 'Ibuprofen',      '400 mg',  'TID',  5,  'Submitted', '2026-06-13'),
    ('10009', 'P003', '4567890123', 'Azithromycin',   '500 mg',  'QD',   3,  'Submitted', '2026-06-12'),
    ('10010', 'P004', '2345678901', 'Amoxicillin',    '125 mg',  'TID',  7,  'Submitted', '2026-06-11');

-- Doctor Decisions (10 records — rx_numbers match prescriptions above)
INSERT INTO doctor_decision (rx_number, status, reason) VALUES
    ('10001', 'ACCEPTED',  NULL),
    ('10002', 'REJECTED',  'Drug interaction with current medication'),
    ('10003', 'MODIFIED',  'Reduced dosage for elderly patient'),
    ('10004', 'ACCEPTED',  NULL),
    ('10005', 'REJECTED',  'Patient has known allergy to prescribed drug'),
    ('10006', 'MODIFIED',  'Changed to generic equivalent for cost savings'),
    ('10007', 'ACCEPTED',  NULL),
    ('10008', 'MODIFIED',  'Extended duration from 7 days to 14 days'),
    ('10009', 'REJECTED',  'Duplicate prescription already active'),
    ('10010', 'MODIFIED',  'Switched to liquid form for pediatric patient');

-- RX Status Tracking (10 records — rx_numbers match prescriptions above)
INSERT INTO rx_status_tracking (rx_number, status, agents_done, agents_pending, estimated_wait_s) VALUES
    ('10001', 'COMPLETED',   '["clinical","financial","pbm"]',     '[]',                        0),
    ('10002', 'FAILED',      '["clinical"]',                       '["financial","pbm"]',       0),
    ('10003', 'PROCESSING',  '["clinical"]',                       '["financial","pbm"]',       12),
    ('10004', 'COMPLETED',   '["clinical","financial","pbm"]',     '[]',                        0),
    ('10005', 'ESCALATED',   '["clinical","financial"]',           '["pbm"]',                   45),
    ('10006', 'PROCESSING',  '["clinical"]',                       '["financial"]',             8),
    ('10007', 'COMPLETED',   '["clinical","financial","pbm"]',     '[]',                        0),
    ('10008', 'PENDING_PA',  '["clinical","financial"]',           '["pbm","pa_review"]',       120),
    ('10009', 'FAILED',      '["clinical"]',                       '["financial","pbm"]',       0),
    ('10010', 'PROCESSING',  '[]',                                 '["clinical","financial"]',  25);

-- PBM Response (10 records with ai_confidence — rx_numbers match prescriptions)
INSERT INTO pbm_response (rx_number, status, ai_confidence, prescribed_drug, diagnosis, recommended_alt, cost_impact, safety_summary, policy_compliance) VALUES
    ('10001', 'APPROVED',        0.95, 'Paracetamol 500mg',    'Acute pain',                  NULL,                     0,    'No major risk',                           'Fully compliant'),
    ('10002', 'DENIED',          0.88, 'Amoxicillin 250mg',    'Bacterial infection',          'Cephalexin 250mg',       800,  'Drug interaction with warfarin detected',  'Requires step therapy'),
    ('10003', 'ESCALATED',       0.72, 'Metformin 850mg',      'Type 2 Diabetes',             'Generic Metformin',      2100, 'No major risk',                           'Needs approval'),
    ('10004', 'APPROVED',        0.97, 'Lisinopril 10mg',      'Hypertension',                NULL,                     0,    'No contraindications',                    'Fully compliant'),
    ('10005', 'DENIED',          0.91, 'Cetirizine 10mg',      'Allergic rhinitis',           'Loratadine 10mg',        350,  'Known allergy to cetirizine',             'Not covered under plan'),
    ('10006', 'ESCALATED',       0.65, 'Atorvastatin 20mg',    'Hyperlipidemia',              'Rosuvastatin 10mg',      1500, 'Minimal risk, monitor liver enzymes',     'Prior auth required'),
    ('10007', 'APPROVED',        0.99, 'Omeprazole 20mg',      'GERD',                        NULL,                     0,    'No contraindications',                    'Fully compliant'),
    ('10008', 'PENDING_REVIEW',  0.54, 'Ibuprofen 400mg',      'Chronic pain',                'Naproxen 250mg',        400,  'GI bleeding risk in elderly',             'Quantity limit exceeded'),
    ('10009', 'DENIED',          0.83, 'Azithromycin 500mg',   'Upper respiratory infection',  'Amoxicillin 500mg',     600,  'QT prolongation risk',                    'Duplicate therapy'),
    ('10010', 'ESCALATED',       0.61, 'Amoxicillin 125mg',    'Pediatric ear infection',     'Amoxicillin Suspension', 200,  'Age-appropriate dosing required',         'Formulation change needed');

-- PBM Cost Comparison (1 per PBM response, IDs 1-10 match pbm_response IDs)
INSERT INTO pbm_cost_comparison (pbm_response_id, original_tier, original_price, original_copay, alternative_tier, alternative_price, alternative_copay, savings) VALUES
    (1,  'Tier 1', 200,  20,   'Tier 1', 200,  20,  0),
    (2,  'Tier 2', 1200, 150,  'Tier 1', 400,  50,  800),
    (3,  'Tier 3', 2500, 500,  'Tier 1', 400,  50,  2100),
    (4,  'Tier 1', 300,  30,   'Tier 1', 300,  30,  0),
    (5,  'Tier 2', 600,  80,   'Tier 1', 250,  25,  350),
    (6,  'Tier 3', 2200, 400,  'Tier 2', 700,  100, 1500),
    (7,  'Tier 1', 350,  35,   'Tier 1', 350,  35,  0),
    (8,  'Tier 2', 800,  100,  'Tier 1', 400,  50,  400),
    (9,  'Tier 2', 1100, 120,  'Tier 1', 500,  60,  600),
    (10, 'Tier 1', 450,  45,   'Tier 1', 250,  25,  200);

-- PBM Safety (1 per PBM response)
INSERT INTO pbm_safety (pbm_response_id, contraindications, interactions, monitoring) VALUES
    (1,  'None',                         'None',                          'None required'),
    (2,  'None',                         'Warfarin interaction',          'INR monitoring'),
    (3,  'None',                         'Minimal',                       'Blood sugar'),
    (4,  'None',                         'None',                          'Blood pressure'),
    (5,  'Cetirizine allergy',           'None',                          'Allergy symptoms'),
    (6,  'None',                         'Grapefruit interaction',        'Liver enzymes'),
    (7,  'None',                         'None',                          'None required'),
    (8,  'GI ulcer history',             'Aspirin interaction',           'GI symptoms, renal function'),
    (9,  'None',                         'QT-prolonging drugs',           'ECG monitoring'),
    (10, 'None',                         'None',                          'Weight-based dosing check');

-- PBM Policy (1 per PBM response)
INSERT INTO pbm_policy (pbm_response_id, original_status, alternative_status) VALUES
    (1,  'Fully covered',     'Fully covered'),
    (2,  'Step therapy required', 'Fully covered'),
    (3,  'Needs approval',    'Fully covered'),
    (4,  'Fully covered',     'Fully covered'),
    (5,  'Not covered',       'Fully covered'),
    (6,  'Prior auth required', 'Covered with copay'),
    (7,  'Fully covered',     'Fully covered'),
    (8,  'Quantity limited',  'Fully covered'),
    (9,  'Duplicate denied',  'Fully covered'),
    (10, 'Formulation issue', 'Fully covered');

-- Users (10 records)
INSERT INTO users (username, password_hash, role, is_active) VALUES
    ('doc1',      'pbkdf2:sha256:1000000$salt001$hash001', 'doctor',   1),
    ('doc2',      'pbkdf2:sha256:1000000$salt002$hash002', 'doctor',   1),
    ('doc3',      'pbkdf2:sha256:1000000$salt003$hash003', 'doctor',   1),
    ('doc4',      'pbkdf2:sha256:1000000$salt004$hash004', 'doctor',   0),
    ('prov1',     'pbkdf2:sha256:1000000$salt005$hash005', 'provider', 1),
    ('prov2',     'pbkdf2:sha256:1000000$salt006$hash006', 'provider', 1),
    ('prov3',     'pbkdf2:sha256:1000000$salt007$hash007', 'provider', 1),
    ('prov4',     'pbkdf2:sha256:1000000$salt008$hash008', 'provider', 0),
    ('admin1',    'pbkdf2:sha256:1000000$salt009$hash009', 'admin',    1),
    ('admin2',    'pbkdf2:sha256:1000000$salt010$hash010', 'admin',    1);