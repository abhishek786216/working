import sqlite3
import os

# Remove old DB so we start fresh
if os.path.exists('doctor_decisions.db'):
    os.remove('doctor_decisions.db')

conn = sqlite3.connect('doctor_decisions.db')
conn.execute("PRAGMA foreign_keys = ON")  # Enable FK enforcement
cursor = conn.cursor()

# Read and execute schema
with open('schema.sql', 'r') as f:
    cursor.executescript(f.read())

# Re-enable FK after executescript (it resets pragmas)
conn.execute("PRAGMA foreign_keys = ON")

# Read and execute seed data
with open('seed_data.sql', 'r') as f:
    cursor.executescript(f.read())

conn.commit()

# --- Display Patients ---
print("=" * 30)
print("PATIENTS")
print("=" * 30)
cursor.execute("SELECT * FROM patient")
for row in cursor.fetchall():
    print(f"  {row[0]}")

# --- Display Providers ---
print(f"\n{'=' * 30}")
print("PROVIDERS")
print("=" * 30)
cursor.execute("SELECT * FROM provider")
for row in cursor.fetchall():
    print(f"  {row[0]}")

# --- Display Prescriptions ---
print(f"\n{'=' * 110}")
print("PRESCRIPTIONS")
print("=" * 110)
print(f"{'RX#':<8} {'Patient':<10} {'NPI':<14} {'Drug':<16} {'Dosage':<10} {'Freq':<6} {'Days':<6} {'Status':<12} {'Date Written'}")
print("-" * 110)
cursor.execute("SELECT * FROM prescription")
for row in cursor.fetchall():
    print(f"{row[0]:<8} {row[1]:<10} {row[2]:<14} {row[3]:<16} {row[4]:<10} {row[5]:<6} {row[6]:<6} {row[7]:<12} {row[8]}")

# --- Display Doctor Decisions ---
print(f"\n{'=' * 110}")
print("DOCTOR DECISIONS")
print("=" * 110)
print(f"{'ID':<4} {'RX#':<8} {'Status':<12} {'Reason':<55} {'Created At'}")
print("-" * 110)
cursor.execute("SELECT * FROM doctor_decision")
for row in cursor.fetchall():
    reason = row[3] if row[3] else "—"
    print(f"{row[0]:<4} {row[1]:<8} {row[2]:<12} {reason:<55} {row[4]}")

# --- Joined View ---
print(f"\n{'=' * 110}")
print("JOINED VIEW: Prescription + Doctor Decision")
print("=" * 110)
print(f"{'RX#':<8} {'Drug':<16} {'Patient':<10} {'Decision':<12} {'Reason'}")
print("-" * 110)
cursor.execute("""
    SELECT p.rx_number, p.prod_nm, p.patient_account_id, d.status, d.reason
    FROM prescription p
    JOIN doctor_decision d ON p.rx_number = d.rx_number
""")
for row in cursor.fetchall():
    reason = row[4] if row[4] else "—"
    print(f"{row[0]:<8} {row[1]:<16} {row[2]:<10} {row[3]:<12} {reason}")

# --- Display RX Status Tracking ---
print(f"\n{'=' * 120}")
print("RX STATUS TRACKING (In-progress Response)")
print("=" * 120)
print(f"{'ID':<4} {'RX#':<8} {'Status':<14} {'Agents Done':<35} {'Agents Pending':<30} {'Wait(s)':<8} {'Created At'}")
print("-" * 120)
cursor.execute("SELECT * FROM rx_status_tracking")
for row in cursor.fetchall():
    print(f"{row[0]:<4} {row[1]:<8} {row[2]:<14} {row[3]:<35} {row[4]:<30} {row[5]:<8} {row[6]}")

# --- Full Joined View ---
print(f"\n{'=' * 140}")
print("FULL VIEW: Prescription + Decision + Status Tracking")
print("=" * 140)
print(f"{'RX#':<8} {'Drug':<16} {'Patient':<10} {'Decision':<12} {'Tracking':<14} {'Agents Done':<30} {'Agents Pending':<25} {'Wait(s)'}")
print("-" * 140)
cursor.execute("""
    SELECT p.rx_number, p.prod_nm, p.patient_account_id,
           d.status AS decision, s.status AS tracking,
           s.agents_done, s.agents_pending, s.estimated_wait_s
    FROM prescription p
    JOIN doctor_decision d ON p.rx_number = d.rx_number
    JOIN rx_status_tracking s ON p.rx_number = s.rx_number
""")
for row in cursor.fetchall():
    print(f"{row[0]:<8} {row[1]:<16} {row[2]:<10} {row[3]:<12} {row[4]:<14} {row[5]:<30} {row[6]:<25} {row[7]}")

# --- Display PBM Response ---
print(f"\n{'=' * 140}")
print("PBM RESPONSE (with AI Confidence)")
print("=" * 140)
print(f"{'ID':<4} {'RX#':<8} {'Status':<16} {'AI Conf':<9} {'Drug':<22} {'Diagnosis':<25} {'Alt':<22} {'Savings':<9} {'Safety Summary'}")
print("-" * 140)
cursor.execute("SELECT * FROM pbm_response")
for row in cursor.fetchall():
    alt = row[6] if row[6] else "—"
    print(f"{row[0]:<4} {row[1]:<8} {row[2]:<16} {row[3]:<9.2f} {row[4]:<22} {row[5]:<25} {alt:<22} {row[7]:<9.0f} {row[8]}")

# --- Display PBM Cost Comparison ---
print(f"\n{'=' * 120}")
print("PBM COST COMPARISON")
print("=" * 120)
print(f"{'ID':<4} {'Resp#':<7} {'Orig Tier':<12} {'Orig Price':<12} {'Orig Copay':<12} {'Alt Tier':<12} {'Alt Price':<12} {'Alt Copay':<12} {'Savings'}")
print("-" * 120)
cursor.execute("SELECT * FROM pbm_cost_comparison")
for row in cursor.fetchall():
    print(f"{row[0]:<4} {row[1]:<7} {row[2]:<12} {row[3]:<12.0f} {row[4]:<12.0f} {row[5]:<12} {row[6]:<12.0f} {row[7]:<12.0f} {row[8]:.0f}")

# --- Display PBM Safety ---
print(f"\n{'=' * 100}")
print("PBM SAFETY")
print("=" * 100)
print(f"{'ID':<4} {'Resp#':<7} {'Contraindications':<25} {'Interactions':<25} {'Monitoring'}")
print("-" * 100)
cursor.execute("SELECT * FROM pbm_safety")
for row in cursor.fetchall():
    print(f"{row[0]:<4} {row[1]:<7} {row[2]:<25} {row[3]:<25} {row[4]}")

# --- Display PBM Policy ---
print(f"\n{'=' * 80}")
print("PBM POLICY")
print("=" * 80)
print(f"{'ID':<4} {'Resp#':<7} {'Original Status':<25} {'Alternative Status'}")
print("-" * 80)
cursor.execute("SELECT * FROM pbm_policy")
for row in cursor.fetchall():
    print(f"{row[0]:<4} {row[1]:<7} {row[2]:<25} {row[3]}")

# --- Complete Pipeline View ---
print(f"\n{'=' * 150}")
print("COMPLETE PIPELINE: Prescription -> PBM -> Decision")
print("=" * 150)
print(f"{'RX#':<8} {'Drug':<18} {'Patient':<8} {'PBM Status':<16} {'AI Conf':<9} {'Decision':<12} {'Tracking':<14} {'Savings'}")
print("-" * 150)
cursor.execute("""
    SELECT p.rx_number, p.prod_nm, p.patient_account_id,
           pbm.status AS pbm_status, pbm.ai_confidence,
           d.status AS decision, s.status AS tracking,
           pbm.cost_impact
    FROM prescription p
    JOIN pbm_response pbm ON p.rx_number = pbm.rx_number
    JOIN doctor_decision d ON p.rx_number = d.rx_number
    JOIN rx_status_tracking s ON p.rx_number = s.rx_number
""")
for row in cursor.fetchall():
    print(f"{row[0]:<8} {row[1]:<18} {row[2]:<8} {row[3]:<16} {row[4]:<9.2f} {row[5]:<12} {row[6]:<14} {row[7]:.0f}")

conn.close()
