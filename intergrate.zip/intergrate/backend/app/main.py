from fastapi import FastAPI, HTTPException
from typing import Any, Dict

from app.tools.lookups import lookup_pbm_context
from app.agents.orchestrator import run_claim

app = FastAPI()

@app.get("/")
def home():
    return {"message": "API Running"}


@app.post("/resolve-intake")
def resolve_intake(payload: dict):
    return lookup_pbm_context(payload)


@app.post("/api/orchestrate")
async def orchestrate_claim(payload: Dict[str, Any]):
    """
    Orchestrate a claim through the multi-agent decision engine.
    
    Expected payload keys:
    - drug_id (str): Product identifier
    - member_id (str): Member/patient identifier  
    - plan_id (str): Insurance plan identifier
    - quantity (int, optional): Quantity to dispense
    - fill_date (str, optional): ISO format date (YYYY-MM-DD)
    - diagnosis (str, optional): ICD code or description
    - current_meds (list, optional): List of current medications
    - trace_id (str, optional): Custom trace ID; auto-generated if omitted
    
    Returns the orchestrator decision with summary, final_candidates, and detailed agent feedback.
    """
    try:
        if not all(k in payload for k in ["drug_id", "member_id", "plan_id"]):
            raise HTTPException(
                status_code=400,
                detail="Missing required fields: drug_id, member_id, plan_id"
            )
        
        result = await run_claim(payload)
        return result
    
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Orchestration failed: {str(e)}"
        )
