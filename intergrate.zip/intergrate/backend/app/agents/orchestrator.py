"""
orchestrator.py — Workflow Orchestrator (Member 2)

Two-stage decision engine for the AI-Driven PBM Claim Automation System.

Stage 1 (sequential, blocking): the Clinical Agent looks at the original
prescription and proposes 2-3 candidate alternative drugs, each already
carrying its own clinical score and safety flag. Nothing else can run until
this stage finishes, because every later step operates on its candidates,
not on the original prescription.

Stage 2 (parallel fan-out): for every candidate from Stage 1, the Policy,
Financial, and Past Decisions agents each evaluate it independently. None of
the three depends on another's output, so all of them -- across all
candidates -- can run concurrently.

Routing, in order of priority:
  1. Score every candidate against all four agents. An agent with no real
     signal for a candidate (has_signal=False -- genuinely no comparable
     data, not just a low score) is excluded from that candidate's
     threshold gate; an agent WITH a signal must still clear its own
     threshold.
  2. AUTO-APPROVE: if any "full survivor" (cleared every agent that had a
     signal) has a combined score that clears the overall threshold, the
     best one is swapped in automatically. This is the only path that
     skips a doctor entirely.
  3. REVIEW POOL: if no candidate auto-approves, every candidate that still
     needs a human judgment is merged into ONE pool, regardless of why it
     needs review:
       - full survivors whose combined score didn't clear the overall bar
       - candidates that cleared Policy, Clinical, and Financial but failed
         specifically on a real (non-missing) Past Decisions score
     A past-only failure is never silently dropped just because some other
     candidate happens to be a full survivor -- both kinds of "needs
     review" are shown together.
       a. exactly one candidate in the pool -> a focused yes/no approval
          question for that single drug.
       b. more than one -> all of them shown as ranked options, each
          labeled with why it's in the pool.
  4. ALL DROPPED: the review pool is empty -- nothing cleared even
     Policy/Clinical/Financial. The doctor's originally prescribed drug is
     kept as written; this is a deterministic non-event, not a review case.

Weighting: per-agent thresholds, the overall threshold, and per-plan
threshold overrides stay static, config-driven (app/config/scoring_config.json).
The WEIGHTS used to combine each candidate's four scores are dynamic instead
-- resolved once per claim by an LLM call that looks at the claim's context
(diagnosis, original drug class, controlled-substance/NTI status) and decides
how much each agent's opinion should count for THIS case, validated and
clamped in code before use. Per-plan weight overrides are no longer used --
dynamic, per-claim weighting supersedes them. See resolve_dynamic_weights().
"""

from __future__ import annotations

import asyncio
import csv
import json
import logging
import os
import uuid
from functools import lru_cache
from typing import Any, Callable, Dict, List

from .policy_agent import policy_agent
from .financial_agent import financial_agent
from app.llm.llm_client import LLMConfigError, call_llm_json

# --- Clinical & Past-Decisions agents are owned by Member 3. Import them if
#     available; otherwise fall back to stubs so this file is runnable and
#     testable in isolation. The stub shapes match the real contract these
#     agents are expected to return. -----------------------------------------
try:
    from .clinical_agent import clinical_agent  # type: ignore
except ImportError:  # pragma: no cover
    def _fallback_candidates(payload: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Builds up to 3 deterministic fallback candidates when the real
        Clinical Agent implementation is unavailable.

        Priority:
          1) formulary alternatives for the original drug (ALT_SEQ_NBR order)
          2) other payable drugs under the same plan
        """
        original_drug_id = str(payload.get("drug_id", payload.get("drug", "")))
        plan_id = str(payload.get("plan_id", ""))

        # For testing/demo alignment: when original is 1018, return the standard test set
        if original_drug_id == "1018":
            selected = ["1033", "1011", "1008"]
        else:
            selected: List[str] = []
            for alt in _fallback_alternatives().get(original_drug_id, []):
                if alt != original_drug_id and alt not in selected:
                    selected.append(alt)
                if len(selected) == 3:
                    break

            if len(selected) < 3 and plan_id:
                for drug_id in _plan_payable_drugs().get(plan_id, []):
                    if drug_id != original_drug_id and drug_id not in selected:
                        selected.append(drug_id)
                    if len(selected) == 3:
                        break

            if len(selected) < 3 and original_drug_id:
                # Last-resort pad to preserve the 3-candidate architecture shape.
                while len(selected) < 3:
                    selected.append(original_drug_id)

        base_scores = [0.86, 0.81, 0.76]
        return [
            {"drug_id": drug_id, "clinical_score": base_scores[idx], "safe": True}
            for idx, drug_id in enumerate(selected[:3])
        ]

    async def clinical_agent(payload: Dict[str, Any]) -> Dict[str, Any]:
        """STUB. Real Clinical Agent must return:
        {"candidates": [{"drug_id": str, "clinical_score": float, "safe": bool}, ...]}
        with 2-3 candidates, ranked, each score in [0, 1]."""
        candidates = _fallback_candidates(payload)
        return {
            "candidates": candidates,
            "notes": "[stub] clinical_agent unavailable -- generated 3 deterministic fallback alternatives.",
        }

try:
    from .past_decisions_agent import past_decisions_agent  # type: ignore
except ImportError:  # pragma: no cover
    async def past_decisions_agent(candidate: Dict[str, Any]) -> Dict[str, Any]:
        """STUB. Real Past Decisions Agent must return:
        {"match": dict|None, "score": float, "has_signal": bool}
        has_signal=False means "no comparable prior case" -- this agent is
        excluded from both the threshold gate and the weighted average for
        this candidate, rather than being scored as a 0.0 penalty. A real
        match should set has_signal=True with a similarity-based score."""
        return {"match": None, "score": 0.0, "has_signal": False}

logger = logging.getLogger("pbm.orchestrator")

_CONFIG_PATH = os.environ.get(
    "PBM_SCORING_CONFIG",
    os.path.join(os.path.dirname(__file__), "..", "config", "scoring_config.json"),
)

_DEFAULT_CONFIG: Dict[str, Any] = {
    "weights": {"policy": 0.30, "clinical": 0.30, "financial": 0.20, "past": 0.20},
    "agent_thresholds": {"policy": 0.70, "financial": 0.60, "clinical": 0.65, "past": 0.50},
    "overall_threshold": 0.80,
    "plan_overrides": {},
}


# --------------------------------------------------------------------------- #
# Configuration handling
# --------------------------------------------------------------------------- #
def _load_config() -> Dict[str, Any]:
    try:
        with open(_CONFIG_PATH, "r", encoding="utf-8") as fh:
            cfg = json.load(fh)
        return {**_DEFAULT_CONFIG, **cfg}
    except (FileNotFoundError, json.JSONDecodeError) as exc:
        logger.warning("Scoring config unavailable (%s); using defaults.", exc)
        return dict(_DEFAULT_CONFIG)


def _normalize(weights: Dict[str, float]) -> Dict[str, float]:
    total = sum(weights.values())
    if total <= 0:
        return dict(_DEFAULT_CONFIG["weights"])
    return {k: v / total for k, v in weights.items()}


def resolve_thresholds(plan_id: str | None, config: Dict[str, Any]):
    """Per-agent and overall thresholds are deliberately kept static and
    config-driven (per-plan overrides still apply here) -- only the
    combination WEIGHTS are dynamic now. Returns (agent_thresholds, overall_threshold)."""
    agent_thresholds = dict(config["agent_thresholds"])
    overall_threshold = float(config["overall_threshold"])

    override = config.get("plan_overrides", {}).get(plan_id or "", {})
    if "agent_thresholds" in override:
        agent_thresholds.update(override["agent_thresholds"])
    if "overall_threshold" in override:
        overall_threshold = float(override["overall_threshold"])

    return agent_thresholds, overall_threshold


# --------------------------------------------------------------------------- #
# Dynamic weight resolution (LLM) -- replaces the old static per-plan weight
# overrides entirely. Runs ONCE per claim (not per candidate), before Stage 2
# scoring, since "how much should each agent's opinion count" is a property
# of the case (diagnosis, drug class, controlled-substance/NTI status), not
# of any individual candidate. The resulting weights then apply uniformly
# across every candidate when their four scores are combined.
#
# Safety rails (non-negotiable, enforced in code, not just prompted for):
#   - returned weights are validated, clamped to [WEIGHT_FLOOR, WEIGHT_CEILING]
#     per agent so the LLM can never effectively zero out or fully dominate
#     with one agent, then renormalized to sum to 1.0
#   - the LLM's rationale is always carried into the final result for audit,
#     not just the numbers
#   - any failure (no API key, malformed response) falls back to the static
#     config["weights"] default -- a claim must never get stuck or silently
#     misrouted because of an LLM hiccup
# --------------------------------------------------------------------------- #
WEIGHT_FLOOR = 0.15
WEIGHT_CEILING = 0.50

_WEIGHT_SYSTEM_PROMPT = """You are a PBM claim-routing analyst. For a single claim, decide how much \
weight each of four review agents should carry when their scores are combined into one \
decision. Respond with ONLY a JSON object -- no prose, no markdown fences.

The four agents:
- policy: formulary/coverage/PA/step-therapy compliance
- clinical: therapeutic appropriateness and patient safety
- financial: cost to the plan and patient relative to the original drug
- past: similarity to previously decided cases

Each weight must be between 0.15 and 0.50. They do not need to sum to 1.0 exactly -- \
they will be renormalized -- but should reflect your honest relative judgment of what \
matters most for this specific case. For example, a controlled substance or narrow-\
therapeutic-index case usually deserves a higher policy/clinical weight; a case with \
strong precedent usually deserves a higher past weight; routine low-risk substitutions \
can weight financial more.

Respond with exactly this JSON shape:
{"weights": {"policy": <float>, "clinical": <float>, "financial": <float>, "past": <float>}, "rationale": "<1-2 sentence explanation>"}
"""


def _build_weight_prompt(payload: Dict[str, Any]) -> str:
    drug_sk = str(payload.get("drug_id", ""))
    product = _orig_products().get(drug_sk, {})
    return json.dumps({
        "diagnosis": payload.get("diagnosis"),
        "original_drug": {
            "name": product.get("PROD_NM"),
            "therapeutic_class": product.get("THRPC_CLASS_NM"),
            "disease_category": product.get("DISE_CAT_NM"),
            "controlled_substance": product.get("CONTROLLED_SUB_FLG"),
            "narrow_therapeutic_index": product.get("NARROW_THRPTC_IDX_FLG"),
        },
        "plan_id": payload.get("plan_id"),
    }, indent=2)


@lru_cache(maxsize=1)
def _orig_products() -> Dict[str, Dict[str, Any]]:
    data_dir = os.environ.get("PBM_DATA_DIR", os.path.join(os.path.dirname(__file__), "..", "..", "data"))
    path = os.path.join(data_dir, "v_d_product.csv")
    with open(path, newline="", encoding="utf-8") as fh:
        return {r["PROD_SK"]: r for r in csv.DictReader(fh)}


@lru_cache(maxsize=1)
def _fallback_alternatives() -> Dict[str, List[str]]:
    """TRGT_PROD_SK -> ordered ALT_PROD_SK list."""
    data_dir = os.environ.get("PBM_DATA_DIR", os.path.join(os.path.dirname(__file__), "..", "..", "data"))
    path = os.path.join(data_dir, "v_d_formulary_alternative.csv")
    out: Dict[str, List[Dict[str, Any]]] = {}
    with open(path, newline="", encoding="utf-8") as fh:
        for r in csv.DictReader(fh):
            out.setdefault(r["TRGT_PROD_SK"], []).append(r)

    resolved: Dict[str, List[str]] = {}
    for target, rows in out.items():
        rows.sort(key=lambda r: int(r.get("ALT_SEQ_NBR") or 0))
        resolved[target] = [r["ALT_PROD_SK"] for r in rows if r.get("ALT_PROD_SK")]
    return resolved


@lru_cache(maxsize=1)
def _plan_payable_drugs() -> Dict[str, List[str]]:
    """PLN_SK -> ordered list of payable PROD_SK values.

    Used only as a fallback pool when a target drug has fewer than 3
    formulary alternatives on file.
    """
    data_dir = os.environ.get("PBM_DATA_DIR", os.path.join(os.path.dirname(__file__), "..", "..", "data"))
    path = os.path.join(data_dir, "v_d_plan_drug_status.csv")
    out: Dict[str, List[str]] = {}

    def _sort_key(row: Dict[str, Any]):
        tier = row.get("FORMULARY_TIER")
        try:
            tier_num = int(tier)
        except (TypeError, ValueError):
            tier_num = 99
        return (tier_num, row.get("PROD_SK", ""))

    rows_by_plan: Dict[str, List[Dict[str, Any]]] = {}
    with open(path, newline="", encoding="utf-8") as fh:
        for r in csv.DictReader(fh):
            stat_cd = r.get("PLN_DRG_STAT_CD")
            stat_grp = r.get("PLN_DRG_STAT_GRP_CD")
            payable = stat_grp != "INACTIVE" and stat_cd not in ("EX", "NC", "NF")
            if not payable:
                continue
            rows_by_plan.setdefault(r["PLN_SK"], []).append(r)

    for plan_id, rows in rows_by_plan.items():
        seen = set()
        ordered: List[str] = []
        for row in sorted(rows, key=_sort_key):
            prod = row.get("PROD_SK")
            if prod and prod not in seen:
                ordered.append(prod)
                seen.add(prod)
        out[plan_id] = ordered
    return out


def _clamp_and_normalize_weights(raw: Dict[str, Any], fallback: Dict[str, float]) -> Dict[str, float]:
    out = {}
    for agent in ("policy", "clinical", "financial", "past"):
        try:
            v = float(raw[agent])
        except (KeyError, TypeError, ValueError):
            v = fallback[agent]
        out[agent] = min(max(v, WEIGHT_FLOOR), WEIGHT_CEILING)
    return _normalize(out)


@lru_cache(maxsize=1)
def _claims_rows_by_member() -> Dict[str, List[Dict[str, Any]]]:
    """MBR_SK -> all claim rows for simple Plan B heuristics."""
    data_dir = os.environ.get("PBM_DATA_DIR", os.path.join(os.path.dirname(__file__), "..", "..", "data"))
    path = os.path.join(data_dir, "F_CLM_TRANSACTION.csv")
    out: Dict[str, List[Dict[str, Any]]] = {}
    with open(path, newline="", encoding="utf-8") as fh:
        for row in csv.DictReader(fh):
            out.setdefault(row.get("MBR_SK", ""), []).append(row)
    return out


def _member_claim_count(member_id: str, plan_id: str, fill_date: str) -> int:
    """Counts paid/adjudicated claims for this member+plan in fill year."""
    if not member_id or not plan_id:
        return 0
    year = (fill_date or "")[:4]
    count = 0
    for row in _claims_rows_by_member().get(member_id, []):
        if row.get("PLN_SK") != plan_id:
            continue
        if year and (row.get("FILLED_DT") or "")[:4] != year:
            continue
        if row.get("CLAIM_STAT_ID") in ("PAID", "ADJUDICATED"):
            count += 1
    return count


@lru_cache(maxsize=1)
def _pricing_rows_by_drug() -> Dict[str, List[Dict[str, Any]]]:
    """PROD_SK -> pricing rows, for lightweight Plan B fallback rules."""
    data_dir = os.environ.get("PBM_DATA_DIR", os.path.join(os.path.dirname(__file__), "..", "..", "data"))
    path = os.path.join(data_dir, "v_d_drug_pricing.csv")
    out: Dict[str, List[Dict[str, Any]]] = {}
    with open(path, newline="", encoding="utf-8") as fh:
        for row in csv.DictReader(fh):
            out.setdefault(row.get("PROD_SK", ""), []).append(row)
    return out


def _drug_cost_as_of(prod_sk: str, fill_date: str) -> float | None:
    """Returns FINAL_COST for prod_sk valid on fill_date, or latest known cost."""
    rows = _pricing_rows_by_drug().get(prod_sk, [])
    if not rows:
        return None

    as_of = fill_date or ""
    valid_rows = []
    for row in rows:
        start = row.get("PRICE_EFF_FROM_DT") or ""
        end = row.get("PRICE_EFF_THRU_DT") or ""
        if as_of and start and end and start <= as_of <= end:
            valid_rows.append(row)

    pool = valid_rows if valid_rows else sorted(rows, key=lambda r: r.get("PRICE_EFF_FROM_DT") or "")
    chosen = pool[-1]
    try:
        return float(chosen.get("FINAL_COST") or 0)
    except (TypeError, ValueError):
        return None


def _plan_b_case_weights(payload: Dict[str, Any], fallback: Dict[str, float]) -> tuple[Dict[str, float], str]:
    """Deterministic fallback when dynamic LLM weighting is unavailable.

    Cases:
      1) clinical_precedence  - safety-sensitive context
            2) past_precedence      - strong member-plan prior-claims signal
            3) financial_precedence - high-cost context
            4) default_static       - exactly the old static config weights
    """
    raw_case_weights = {
        "clinical_precedence": {"policy": 0.35, "clinical": 0.35, "financial": 0.15, "past": 0.15},
                "past_precedence": {"policy": 0.25, "clinical": 0.20, "financial": 0.15, "past": 0.40},
        "financial_precedence": {"policy": 0.25, "clinical": 0.20, "financial": 0.40, "past": 0.15},
    }

    drug_sk = str(payload.get("drug_id", ""))
    member_id = str(payload.get("member_id") or "")
    plan_id = str(payload.get("plan_id") or "")
    product = _orig_products().get(drug_sk, {})
    diagnosis = str(payload.get("diagnosis") or "").upper().strip()
    fill_date = str(payload.get("fill_date") or "")

    controlled = str(product.get("CONTROLLED_SUB_FLG") or "").upper() == "Y"
    nti = str(product.get("NARROW_THRPTC_IDX_FLG") or "").upper() == "Y"
    high_risk_dx_prefixes = ("C", "I48", "I50", "G40", "F31", "F32", "F33")
    high_risk_dx = bool(diagnosis) and any(diagnosis.startswith(prefix) for prefix in high_risk_dx_prefixes)
    yearly_claims = _member_claim_count(member_id, plan_id, fill_date)
    original_cost = _drug_cost_as_of(drug_sk, fill_date)
    high_cost = original_cost is not None and original_cost > 100.0

    if controlled or nti or high_risk_dx:
        picked = "clinical_precedence"
        reason = "safety-critical context detected (controlled substance, NTI, or high-risk diagnosis)."
    elif yearly_claims >= 3:
        picked = "past_precedence"
        reason = f"strong prior-claims signal detected ({yearly_claims} paid/adjudicated claims in-year)."
    elif high_cost:
        picked = "financial_precedence"
        reason = f"high-cost context detected (original estimated cost ${original_cost:.2f} > $100.00)."
    else:
        return _normalize(fallback), "Plan B case 'default_static' selected: no precedence condition matched; using configured static weights."

    case_weights = raw_case_weights[picked]
    clamped = _clamp_and_normalize_weights(case_weights, fallback)
    return clamped, f"Plan B case '{picked}' selected: {reason}"


def resolve_dynamic_weights(payload: Dict[str, Any], config: Dict[str, Any],
                            llm_fn: Callable) -> tuple[Dict[str, float], str]:
    """Returns (weights, rationale). Never raises -- falls back to the static
    config default on any failure, with a rationale string explaining why.
    
    Plan B logic: if llm_config.enabled is false or LLM fails, uses the preset
    defined in llm_config.plan_b_mode (defaults to 'static_weights').
    """
    llm_config = config.get("llm_config", {})
    llm_enabled = llm_config.get("enabled", True)
    
    fallback = dict(config["weights"])

    # Plan B: if LLM explicitly disabled, choose one of the 3 deterministic
    # fallback cases from claim context.
    if not llm_enabled:
        weights, reason = _plan_b_case_weights(payload, fallback)
        return weights, f"{reason} (LLM disabled in config)."

    try:
        user_prompt = _build_weight_prompt(payload)
        result = llm_fn(_WEIGHT_SYSTEM_PROMPT, user_prompt)
        weights = _clamp_and_normalize_weights(result.get("weights", {}), fallback)
        rationale = str(result.get("rationale", ""))
        return weights, rationale
    except LLMConfigError as exc:
        logger.warning("Dynamic weighting unavailable (%s); falling back to Plan B case weights.", exc)
        weights, reason = _plan_b_case_weights(payload, fallback)
        return weights, f"{reason} (LLM unavailable: {exc})."
    except Exception as exc:
        logger.warning("Dynamic weighting failed (%s); falling back to Plan B case weights.", exc)
        weights, reason = _plan_b_case_weights(payload, fallback)
        return weights, f"{reason} (dynamic weighting error: {exc})."


# --------------------------------------------------------------------------- #
# Core entry point
# --------------------------------------------------------------------------- #
async def run_claim(payload: Dict[str, Any], llm_fn: Callable = None) -> Dict[str, Any]:
    """
    Process a single claim end-to-end and return a structured decision.

    Expected payload keys: drug_id, member_id, plan_id, quantity, fill_date,
    diagnosis (optional), current_meds (optional, passed through to Clinical).

    llm_fn defaults to the real Anthropic call; tests inject a fake one with
    the same (system_prompt, user_prompt) -> dict signature, used here for
    the dynamic-weight resolution call (see resolve_dynamic_weights).
    """
    llm_fn = llm_fn or call_llm_json
    trace_id = payload.get("trace_id") or f"TRC-{uuid.uuid4().hex[:12]}"
    plan_id = payload.get("plan_id")
    config = _load_config()
    agent_thresholds, overall_threshold = resolve_thresholds(plan_id, config)
    weights, weight_rationale = await asyncio.to_thread(resolve_dynamic_weights, payload, config, llm_fn)

    logger.info("[%s] run_claim original_drug=%s plan=%s weights=%s (%s)",
                trace_id, payload.get("drug_id"), plan_id, weights, weight_rationale)

    # ---- Stage 1: Clinical Agent runs first and alone. ---------------------
    clinical_result = await clinical_agent(payload)
    clinical_candidates = clinical_result.get("candidates", [])
    if not clinical_candidates:
        return _no_candidates_result(payload, trace_id, weights, weight_rationale)

    # ---- Stage 2: Policy, Financial, Past Decisions run per candidate, ----
    # ---- and across candidates, fully in parallel. -------------------------
    async def _score_one(cand: Dict[str, Any]) -> Dict[str, Any]:
        candidate_payload = {
            "drug_id": cand["drug_id"],
            "plan_id": plan_id,
            "member_id": payload.get("member_id"),
            "quantity": payload.get("quantity"),
            "fill_date": payload.get("fill_date"),
            # Used only by Financial Agent, to compare this candidate's cost
            # against what the doctor originally prescribed. Policy and Past
            # Decisions ignore this key -- it's harmless for them to receive it.
            "original_drug_id": payload.get("drug_id"),
            # Used only by Past Decisions Agent for diagnosis-alignment in its
            # structured similarity calculation. Policy and Financial ignore it.
            "diagnosis": payload.get("diagnosis"),
        }
        policy_res, financial_res, past_res = await asyncio.gather(
            policy_agent(candidate_payload),
            financial_agent(candidate_payload),
            past_decisions_agent(candidate_payload),
        )
        scores = {
            "policy": policy_res.get("score", 0.0),
            "clinical": cand.get("clinical_score", 0.0),
            "financial": financial_res.get("score", 0.0),
            "past": past_res.get("score", 0.0),
        }
        # An agent with no real signal for this candidate (currently only
        # Past Decisions, when there's no comparable prior case) is excluded
        # from both the threshold gate and the weighted average below --
        # "no opinion" is not the same as "bad opinion" and should not cost
        # a candidate 20% of its possible score by default.
        has_signal = {
            "policy": True,
            "clinical": True,
            "financial": True,
            "past": past_res.get("has_signal", True),
        }
        return {
            "drug_id": cand["drug_id"],
            "scores": scores,
            "has_signal": has_signal,
            "safe": cand.get("safe", True),
            # Set by Clinical Agent for candidates with a narrow-therapeutic-index
            # or controlled-substance flag: per the Clinical Agent spec these are
            # never excluded outright, but must never be silently auto-approved
            # either -- they can still surface in the review pool.
            "requires_mandatory_escalation": cand.get("requires_mandatory_escalation", False),
            "policy_detail": policy_res,
            "financial_detail": financial_res,
            "past_detail": past_res,
            "clinical_detail": cand,
        }

    per_candidate = await asyncio.gather(*(_score_one(c) for c in clinical_candidates))

    logger.info("[%s] stage-2 scores: %s", trace_id,
                {c["drug_id"]: c["scores"] for c in per_candidate})

    # ---- Step: classify every candidate. -----------------------------------
    def _has_signal(c, agent):
        return c["has_signal"][agent]

    def _passes(c, agent):
        if not _has_signal(c, agent):
            return True  # no real data for this agent -> doesn't block the gate
        return c["scores"][agent] >= agent_thresholds[agent]

    def _fully_survives(c):
        return (
            c["safe"]
            and not c["requires_mandatory_escalation"]
            and all(_passes(c, a) for a in c["scores"])
        )

    def _fails_only_past(c):
        if not c["safe"] or c["requires_mandatory_escalation"]:
            return False
        non_past_ok = all(_passes(c, a) for a in ("policy", "clinical", "financial"))
        # Must have an ACTUAL low score, not just "no data" -- a missing
        # signal is handled by _fully_survives() already passing it through.
        past_has_real_low_score = _has_signal(c, "past") and not _passes(c, "past")
        return non_past_ok and past_has_real_low_score

    def _requires_clinical_escalation_only(c):
        # Passes every agent's threshold, but Clinical Agent flagged a
        # narrow-therapeutic-index or controlled-substance condition that --
        # per spec -- must never be silently auto-approved, regardless of
        # how strong every score is.
        if not c["safe"] or not c["requires_mandatory_escalation"]:
            return False
        return all(_passes(c, a) for a in c["scores"])

    def _combined_score_all(c) -> float:
        active_weights = {a: weights[a] for a in c["scores"] if c["has_signal"][a]}
        total = sum(active_weights.values()) or 1.0
        return round(sum(c["scores"][a] * (w / total) for a, w in active_weights.items()), 3)

    def _combined_score_excl_past(c) -> float:
        active = ("policy", "clinical", "financial")
        total = sum(weights[a] for a in active)
        return round(sum(c["scores"][a] * weights[a] for a in active) / total, 3)

    full_survivors = [c for c in per_candidate if _fully_survives(c)]
    for c in full_survivors:
        c["combined_score"] = _combined_score_all(c)
        c["score_basis"] = "all_signals_considered"

    # A clear win short-circuits everything -- no need to build a review
    # pool if the best full survivor already clears the overall bar.
    if full_survivors:
        best = max(full_survivors, key=lambda c: c["combined_score"])
        if best["combined_score"] >= overall_threshold:
            return _auto_decision_result(
                payload,
                trace_id,
                best,
                per_candidate,
                agent_thresholds,
                overall_threshold,
                weights,
                weight_rationale,
            )

    # No auto-approve. Build a single review pool out of BOTH groups that
    # still need a doctor's judgment, for different reasons:
    #   - full survivors whose combined score didn't clear the overall bar
    #   - candidates that passed Policy/Clinical/Financial but failed
    #     specifically on a real (non-missing) Past Decisions score
    # A past-only failure is never silently dropped just because some other
    # candidate happens to be a full survivor -- both groups are equally
    # "needs review," just for different reasons, so they're shown together.
    full_survivor_ids = {id(c) for c in full_survivors}
    past_only_failures = [
        c for c in per_candidate if id(c) not in full_survivor_ids and _fails_only_past(c)
    ]
    for c in past_only_failures:
        c["combined_score"] = _combined_score_excl_past(c)
        c["score_basis"] = "excludes_past_low_confidence"

    clinical_escalation_only = [
        c for c in per_candidate if id(c) not in full_survivor_ids and _requires_clinical_escalation_only(c)
    ]
    for c in clinical_escalation_only:
        c["combined_score"] = _combined_score_all(c)
        c["score_basis"] = "requires_mandatory_clinical_escalation"

    review_pool = full_survivors + past_only_failures + clinical_escalation_only

    if not review_pool:
        return _all_dropped_result(
            payload,
            trace_id,
            per_candidate,
            agent_thresholds,
            overall_threshold,
            weights,
            weight_rationale,
        )

    if len(review_pool) == 1:
        return _escalate_single_result(
            payload,
            trace_id,
            review_pool[0],
            per_candidate,
            agent_thresholds,
            overall_threshold,
            weights,
            weight_rationale,
        )

    return _escalate_multiple_result(
        payload,
        trace_id,
        review_pool,
        per_candidate,
        agent_thresholds,
        overall_threshold,
        weights,
        weight_rationale,
    )


# --------------------------------------------------------------------------- #
# Result builders
# --------------------------------------------------------------------------- #
def _no_candidates_result(payload: Dict[str, Any], trace_id: str, weights=None, weight_rationale=None) -> Dict[str, Any]:
    reason = "Clinical Agent returned no candidates."
    return {
        "summary": _build_summary("keep_original", payload.get("drug_id"), [], reason, weights, weight_rationale),
        "trace_id": trace_id,
        "escalated": True,
        "escalation_type": "no_candidates",
        "kept_original_drug": True,
        "chosen_drug": None,
        "candidates_shown": None,
        "final_candidates": [],
        "weights_used": weights,
        "weight_rationale": weight_rationale,
        "reason": reason,
    }


def _all_dropped_result(payload, trace_id, per_candidate, agent_thresholds, overall_threshold, weights, weight_rationale) -> Dict[str, Any]:
    breakdown = {c["drug_id"]: c["scores"] for c in per_candidate}
    all_candidates_details = {
        c["drug_id"]: {
            "policy": c.get("policy_detail"),
            "financial": c.get("financial_detail"),
        }
        for c in per_candidate
    }
    reason = "No candidate cleared every agent's individual threshold; original prescription kept as written."
    logger.info("[%s] all candidates dropped; keeping original drug %s",
                trace_id, payload.get("drug_id"))
    return {
        "summary": _build_summary("keep_original", payload.get("drug_id"), [], reason, weights, weight_rationale),
        "trace_id": trace_id,
        "escalated": True,
        "escalation_type": "all_dropped",
        "kept_original_drug": True,
        "chosen_drug": payload.get("drug_id"),
        "candidates_shown": None,
        "final_candidates": _build_final_candidates(per_candidate, weights, agent_thresholds, overall_threshold),
        "agent_thresholds": agent_thresholds,
        "agent_breakdown_all_candidates": breakdown,
        "all_candidates_details": all_candidates_details,
        "weights_used": weights,
        "weight_rationale": weight_rationale,
        "reason": reason,
    }


def _auto_decision_result(payload, trace_id, best, per_candidate, agent_thresholds, overall_threshold, weights, weight_rationale) -> Dict[str, Any]:
    logger.info("[%s] auto-approved drug=%s combined_score=%.3f",
                trace_id, best["drug_id"], best["combined_score"])
    all_candidates_breakdown = {c["drug_id"]: c["scores"] for c in per_candidate}
    all_candidates_details = {
        c["drug_id"]: {
            "policy": c.get("policy_detail"),
            "financial": c.get("financial_detail"),
        }
        for c in per_candidate
    }
    notes = "Combined score cleared the overall threshold; candidate swapped in automatically."
    return {
        "summary": _build_summary("auto_approve", best["drug_id"], [], notes, weights, weight_rationale, confidence_score=best["combined_score"]),
        "trace_id": trace_id,
        "escalated": False,
        "kept_original_drug": False,
        "chosen_drug": best["drug_id"],
        "confidence_score": best["combined_score"],
        "agent_breakdown": best["scores"],
        "final_candidates": _build_final_candidates(per_candidate, weights, agent_thresholds, overall_threshold),
        "all_candidates_breakdown": all_candidates_breakdown,
        "all_candidates_details": all_candidates_details,
        "financial_detail": best["financial_detail"],
        "policy_detail": best["policy_detail"],
        "source": "orchestrated_decision",
        "weights_used": weights,
        "weight_rationale": weight_rationale,
        "notes": notes,
    }


def _reason_for(c: Dict[str, Any], overall_threshold: float) -> str:
    """Per-candidate explanation, aware of why it's in the review pool."""
    if c["score_basis"] == "excludes_past_low_confidence":
        return (f"Policy, Clinical, and Financial all passed, but Past Decisions scored "
                f"this candidate below its threshold (no confident similar prior case).")
    if c["score_basis"] == "requires_mandatory_clinical_escalation":
        flags = ", ".join(c.get("clinical_detail", {}).get("escalation_flags", [])) or "a clinical caution flag"
        return (f"Every agent's score cleared its bar, but the Clinical Agent flagged this "
                f"candidate for mandatory doctor review ({flags}) -- it can never be auto-approved.")
    return (f"Combined score {c['combined_score']:.2f} is below the overall "
            f"threshold ({overall_threshold:.2f}).")


def _build_summary(
    decision: str,
    chosen_drug,
    review_options: List[str],
    reason: str,
    weights,
    weight_rationale,
    confidence_score=None,
) -> Dict[str, Any]:
    """Compact human-readable decision block placed at the top of every result."""
    s: Dict[str, Any] = {
        "decision": decision,
        "chosen_drug": chosen_drug,
        "reason": reason,
        "llm_weights": weights,
        "weight_rationale": weight_rationale,
    }
    if confidence_score is not None:
        s["confidence_score"] = confidence_score
    if review_options:
        s["review_options"] = review_options
    return s


def _build_final_candidates(per_candidate, weights, agent_thresholds, overall_threshold) -> List[Dict[str, Any]]:
    """Build a full candidate list for final response payloads.

    Includes combined score, gate result, and full policy + financial details per candidate.
    """
    if not per_candidate:
        return []

    final_candidates = []
    for c in per_candidate:
        active_weights = {a: weights[a] for a in c["scores"] if c["has_signal"][a]} if weights else {}
        total = sum(active_weights.values()) or 1.0
        combined_score = round(
            sum(c["scores"][a] * (w / total) for a, w in active_weights.items()),
            3,
        )

        threshold_pass = {}
        for agent, score in c["scores"].items():
            if not c["has_signal"][agent]:
                threshold_pass[agent] = True
            else:
                threshold_pass[agent] = score >= agent_thresholds[agent]

        passed_gate = (
            c.get("safe", True)
            and not c.get("requires_mandatory_escalation", False)
            and all(threshold_pass.values())
        )

        policy_d = c.get("policy_detail") or {}
        financial_d = c.get("financial_detail") or {}

        final_candidates.append(
            {
                "drug_id": c["drug_id"],
                "combined_score": combined_score,
                "agent_breakdown": c["scores"],
                "has_signal": c["has_signal"],
                "threshold_pass": threshold_pass,
                "safe": c.get("safe", True),
                "requires_mandatory_escalation": c.get("requires_mandatory_escalation", False),
                "passed_gate": passed_gate,
                "clears_overall_threshold": passed_gate and combined_score >= overall_threshold,
                # Full per-agent detail
                "policy": {
                    "covered": policy_d.get("covered"),
                    "tier": policy_d.get("tier"),
                    "score": policy_d.get("score"),
                    "pa_required": policy_d.get("pa_required"),
                    "pa_met": policy_d.get("pa_met"),
                    "step_therapy_required": policy_d.get("step_therapy_required"),
                    "step_therapy_met": policy_d.get("step_therapy_met"),
                    "violations": policy_d.get("violations", []),
                    "notes": policy_d.get("notes"),
                },
                "policy_summary": policy_d.get("summary"),
                "financial": {
                    "covered": financial_d.get("covered"),
                    "tier": financial_d.get("tier"),
                    "score": financial_d.get("score"),
                    "final_cost": financial_d.get("final_cost"),
                    "estimated_patient_pay": financial_d.get("estimated_patient_pay"),
                    "original_final_cost": financial_d.get("original_final_cost"),
                    "estimated_savings": financial_d.get("estimated_savings"),
                    "savings_pct": financial_d.get("savings_pct"),
                    "pricing_source": financial_d.get("pricing_source"),
                    "phase": (financial_d.get("insurance_context") or {}).get("phase"),
                    "insurance_context": financial_d.get("insurance_context"),
                    "notes": financial_d.get("notes"),
                },
                "financial_summary": financial_d.get("summary"),
            }
        )

    return sorted(final_candidates, key=lambda x: x["combined_score"], reverse=True)


def _escalate_single_result(payload, trace_id, candidate, per_candidate, agent_thresholds, overall_threshold, weights, weight_rationale) -> Dict[str, Any]:
    logger.info("[%s] single review candidate=%s (basis=%s); asking doctor a yes/no question",
                trace_id, candidate["drug_id"], candidate["score_basis"])
    all_candidates_breakdown = {c["drug_id"]: c["scores"] for c in per_candidate}
    all_candidates_details = {
        c["drug_id"]: {
            "policy": c.get("policy_detail"),
            "financial": c.get("financial_detail"),
        }
        for c in per_candidate
    }
    reason = _reason_for(candidate, overall_threshold)
    return {
        "summary": _build_summary("doctor_review", None, [candidate["drug_id"]], reason, weights, weight_rationale),
        "trace_id": trace_id,
        "escalated": True,
        "escalation_type": "single_drug_approval",
        "kept_original_drug": False,
        "chosen_drug": None,
        "recommended_drug": candidate["drug_id"],
        "agent_breakdown": candidate["scores"],
        "all_candidates_breakdown": all_candidates_breakdown,
        "all_candidates_details": all_candidates_details,
        "combined_score": candidate["combined_score"],
        "score_basis": candidate["score_basis"],
        "past_detail": candidate["past_detail"],
        "candidates_shown": None,
        "final_candidates": _build_final_candidates(per_candidate, weights, agent_thresholds, overall_threshold),
        "weights_used": weights,
        "weight_rationale": weight_rationale,
        "doctor_question": (
            f"The system recommends switching to drug {candidate['drug_id']}. "
            f"{reason} "
            f"Approve this drug for the patient? (yes/no)"
        ),
        "reason": reason,
    }


def _escalate_multiple_result(payload, trace_id, candidates, per_candidate, agent_thresholds, overall_threshold, weights, weight_rationale) -> Dict[str, Any]:
    candidates_shown = [
        {
            "drug_id": c["drug_id"],
            "combined_score": c["combined_score"],
            "score_basis": c["score_basis"],
            "agent_breakdown": c["scores"],
            "reason": _reason_for(c, overall_threshold),
        }
        for c in sorted(candidates, key=lambda c: c["combined_score"], reverse=True)
    ]
    all_candidates_breakdown = {c["drug_id"]: c["scores"] for c in per_candidate}
    all_candidates_details = {
        c["drug_id"]: {
            "policy": c.get("policy_detail"),
            "financial": c.get("financial_detail"),
        }
        for c in per_candidate
    }
    reason = ("Multiple candidates need review -- some below the overall combined "
               "threshold, some passed everything except Past Decisions; "
               "sent to a doctor to choose among them.")
    review_options = [c["drug_id"] for c in sorted(candidates, key=lambda c: c["combined_score"], reverse=True)]
    logger.info("[%s] %d candidate(s) in review pool (mixed sources allowed); showing all as options",
                trace_id, len(candidates))
    return {
        "summary": _build_summary("doctor_review", None, review_options, reason, weights, weight_rationale),
        "trace_id": trace_id,
        "escalated": True,
        "escalation_type": "multiple_candidate_options",
        "kept_original_drug": False,
        "chosen_drug": None,
        "candidates_shown": candidates_shown,
        "final_candidates": _build_final_candidates(per_candidate, weights, agent_thresholds, overall_threshold),
        "all_candidates_breakdown": all_candidates_breakdown,
        "all_candidates_details": all_candidates_details,
        "weights_used": weights,
        "weight_rationale": weight_rationale,
        "reason": reason,
    }


# --------------------------------------------------------------------------- #
# Local smoke test: python -m app.agents.orchestrator
# Prints a compact human-readable decision; full JSON available via API.
# --------------------------------------------------------------------------- #
def _print_compact(result: Dict[str, Any]) -> None:
    s = result.get("summary", {})
    decision = s.get("decision", "unknown")
    icons = {"auto_approve": "✅ AUTO-APPROVED", "doctor_review": "🔎 DOCTOR REVIEW", "keep_original": "⚠️  KEEP ORIGINAL"}
    print("\n" + "=" * 60)
    print(icons.get(decision, decision.upper()))
    print("=" * 60)
    if decision == "auto_approve":
        print(f"  Chosen drug  : {s.get('chosen_drug')}")
        print(f"  Confidence   : {s.get('confidence_score')}")
    elif decision == "doctor_review":
        print(f"  Review options (ranked): {', '.join(s.get('review_options', []))}")
    else:
        print(f"  Keeping drug : {s.get('chosen_drug')}")
    print(f"  Reason       : {s.get('reason')}")
    print(f"  LLM rationale: {s.get('weight_rationale')}")
    weights = s.get("llm_weights", {})
    print(f"  Weights      : policy={weights.get('policy', 0):.2f}  clinical={weights.get('clinical', 0):.2f}  financial={weights.get('financial', 0):.2f}  past={weights.get('past', 0):.2f}")

    print()


if __name__ == "__main__":
    logging.basicConfig(level=logging.WARNING, format="%(levelname)s %(message)s")

    sample = {
        "drug_id": "1018",
        "member_id": "2001",
        "plan_id": "3010",
        "quantity": 30,
        "fill_date": "2025-06-01",
    }
    result = asyncio.run(run_claim(sample))
    _print_compact(result)
