"""
past_decisions_agent.py — Past Decisions Agent Stub (Member 3)

Looks up similar past approval/denial decisions for this member under similar
clinical/formulary conditions and scores the candidate based on precedent.

Currently a stub that returns random scores for testing/development.
Real implementation owned by Member 3.

Input contract (one candidate):
    {
        "drug_id":      str   PROD_SK of the candidate drug
        "plan_id":      str   PLN_SK
        "member_id":    str   MEMBER_ID (optional)
        "diagnosis":    str   ICD code (optional)
        "fill_date":    str   ISO date (optional)
    }

Output contract:
    {
        "score":       float  0.0-1.0 similarity/precedent score
        "has_signal":  bool   True if comparable past case found; False if no
                              comparable data (missing == no signal, not bad signal)
        "match":       dict   Best matching past case (optional)
        "notes":       str    Explanation of the precedent or lack thereof
    }
"""

from __future__ import annotations

import asyncio
import random
import logging
from typing import Any, Dict

logger = logging.getLogger("pbm.past_decisions_agent")


async def past_decisions_agent(candidate: Dict[str, Any]) -> Dict[str, Any]:
    """Stub that returns a random score between 0.0 and 1.0."""
    return await asyncio.to_thread(_evaluate, candidate)


def _evaluate(candidate: Dict[str, Any]) -> Dict[str, Any]:
    """Stub evaluation: random score with has_signal=True for now."""
    score = round(random.uniform(0.0, 1.0), 3)
    return {
        "drug_id": candidate.get("drug_id"),
        "score": score,
        "has_signal": True,  # Always signal for now (can randomize later if needed)
        "match": None,
        "notes": "[stub] past_decisions_agent not yet implemented -- returning random score.",
    }


# --------------------------------------------------------------------------- #
# Local smoke test: python -m app.agents.past_decisions_agent
# --------------------------------------------------------------------------- #
if __name__ == "__main__":
    import json

    async def _demo():
        candidate = {
            "drug_id": "1033",
            "plan_id": "3010",
            "member_id": "2001",
        }
        result = await past_decisions_agent(candidate)
        print(json.dumps({"candidate": candidate, "result": result}, indent=2))

    logging.basicConfig(level=logging.INFO)
    asyncio.run(_demo())
