-- ============================================
-- Seed Data
-- ============================================

-- Patients (6 patients)
INSERT INTO patient (patient_account_id) VALUES
    ('P001'), ('P002'), ('P003'), ('P004'), ('P005'), ('P006');

-- Providers (4 providers)
INSERT INTO provider (npi_number) VALUES
    ('1234567890'), ('2345678901'), ('3456789012'), ('4567890123');

-- Prescriptions (10 records)
INSERT INTO prescription (rx_number, patient_account_id, npi_number, prod_nm, dosage_size, frequency, days_supply, rx_status, date_written) VALUES
    ('10001', 'P001', '1234567890', 'Metformin ER',          '500 mg',  'BID',  90, 'Submitted', '2026-06-20'),
    ('10002', 'P002', '2345678901', 'Apixaban',              '5 mg',    'BID',  30, 'Submitted', '2026-06-19'),
    ('10003', 'P003', '1234567890', 'Semaglutide',           '0.5 mg',  'QD',   28, 'Submitted', '2026-06-18'),
    ('10004', 'P001', '3456789012', 'Lisinopril',            '20 mg',   'QD',   90, 'Submitted', '2026-06-17'),
    ('10005', 'P004', '2345678901', 'Adalimumab',            '40 mg',   'BID',  28, 'Submitted', '2026-06-16'),
    ('10006', 'P005', '4567890123', 'Rosuvastatin',          '20 mg',   'QD',   90, 'Submitted', '2026-06-15'),
    ('10007', 'P002', '1234567890', 'Omeprazole',            '20 mg',   'QD',   30, 'Submitted', '2026-06-14'),
    ('10008', 'P006', '3456789012', 'Ibuprofen',             '800 mg',  'TID',  14, 'Submitted', '2026-06-13'),
    ('10009', 'P003', '4567890123', 'Azithromycin',          '500 mg',  'QD',   5,  'Submitted', '2026-06-12'),
    ('10010', 'P004', '2345678901', 'Amoxicillin Suspension','400 mg',  'BID',  10, 'Submitted', '2026-06-11');

-- Doctor Decisions (8 records — escalated cases include accepted/modified/rejected plus pending in dashboard)
INSERT INTO doctor_decision (rx_number, status, reason) VALUES
    ('10001', 'ACCEPTED',  NULL),
    ('10003', 'MODIFIED',  'Adjusted to formulary-preferred GLP-1 with equivalent glycemic efficacy and lower member cost share.'),
    ('10004', 'ACCEPTED',  NULL),
    ('10005', 'REJECTED',  'Biologic request does not meet step-therapy criteria; methotrexate trial not documented.'),
    ('10006', 'ACCEPTED',  NULL),
    ('10007', 'ACCEPTED',  NULL),
    ('10008', 'MODIFIED',  'Converted to short-course NSAID with GI prophylaxis due to ulcer risk profile.'),
    ('10010', 'MODIFIED',  'Dose and formulation adjusted to guideline-based pediatric otitis media regimen.');

-- RX status tracking removed — simplified flow uses `prescription`, `pbm_response` and `doctor_decision`

-- PBM Response (10 records with ai_confidence — rx_numbers match prescriptions)
INSERT INTO pbm_response (rx_number, status, ai_confidence, prescribed_drug, diagnosis, recommended_alt, cost_impact, safety_summary, policy_compliance) VALUES
('10001', 'APPROVED',  0.94, 'Metformin ER 500mg',           'Type 2 diabetes mellitus',     NULL,                           0,    'No major safety signal; renal function acceptable.',         'Formulary preferred, no PA or step edits.'),
('10002', 'ESCALATED', 0.67, 'Apixaban 5mg',                'Atrial fibrillation',          'Rivaroxaban 20mg',              95,   'Concomitant antiplatelet therapy increases bleed risk.',      'Prior authorization required for this line of therapy.'),
('10003', 'ESCALATED', 0.62, 'Semaglutide 0.5mg',           'Type 2 diabetes with obesity', 'Liraglutide 1.8mg',              210,  'Monitor GI intolerance and pancreatitis warning criteria.',    'Step therapy not satisfied per current claims history.'),
('10004', 'APPROVED',  0.96, 'Lisinopril 20mg',             'Essential hypertension',       NULL,                           0,    'No contraindications noted in profile.',                      'Covered as Tier 1 preferred generic.'),
('10005', 'ESCALATED', 0.51, 'Adalimumab 40mg',             'Rheumatoid arthritis',         'Etanercept 50mg',               580,  'Biologic therapy requires infection screening verification.',  'Non-preferred biologic; PA and step-therapy criteria open.'),
('10006', 'APPROVED',  0.92, 'Rosuvastatin 20mg',           'Mixed hyperlipidemia',         NULL,                           0,    'Monitor liver enzymes per statin protocol.',                 'Covered with standard quantity limit.'),
('10007', 'APPROVED',  0.91, 'Omeprazole 20mg',             'GERD',                         NULL,                           0,    'No major interaction risk with active meds.',                'Preferred PPI on formulary.'),
('10008', 'ESCALATED', 0.58, 'Ibuprofen 800mg',             'Chronic low back pain',        'Naproxen 500mg',                34,   'High-dose NSAID raises GI/renal risk in this profile.',       'Quantity and duration exceed plan soft limits.'),
('10009', 'ESCALATED', 0.74, 'Azithromycin 500mg',          'Acute bronchitis',             'Doxycycline 100mg',             42,   'QT interval caution; evaluate indication appropriateness.',    'Antibiotic stewardship edit triggered for diagnosis coding.'),
('10010', 'ESCALATED', 0.65, 'Amoxicillin Suspension 400mg','Acute otitis media (peds)',    'Amoxicillin-clavulanate ES',    18,   'Weight-based dosing check required for pediatric regimen.',    'Formulary covered after pediatric dosing validation.');

-- PBM Cost Comparison (1 per PBM response, IDs 1-10 match pbm_response IDs)
INSERT INTO pbm_cost_comparison (pbm_response_id, original_tier, original_price, original_copay, alternative_tier, alternative_price, alternative_copay, savings) VALUES
    (1,  'Tier 1',  28.00,   8.00,  'Tier 1',  28.00,   8.00,   0.00),
    (2,  'Tier 3',  612.00, 120.00, 'Tier 2',  517.00,  95.00, 95.00),
    (3,  'Tier 3',  985.00, 180.00, 'Tier 2',  775.00, 135.00, 210.00),
    (4,  'Tier 1',  14.00,   4.00,  'Tier 1',  14.00,   4.00,   0.00),
    (5,  'Tier 4',  3540.00, 620.00,'Tier 3', 2960.00, 520.00, 580.00),
    (6,  'Tier 1',  24.00,   7.00,  'Tier 1',  24.00,   7.00,   0.00),
    (7,  'Tier 1',  18.00,   5.00,  'Tier 1',  18.00,   5.00,   0.00),
    (8,  'Tier 2',  26.00,  10.00,  'Tier 1',   9.00,   6.00,  17.00),
    (9,  'Tier 2',  32.00,  11.00,  'Tier 1',  14.00,   7.00,  18.00),
    (10, 'Tier 2',  22.00,   9.00,  'Tier 2',  18.00,   8.00,   4.00);

-- PBM Safety (1 per PBM response)
INSERT INTO pbm_safety (pbm_response_id, contraindications, interactions, monitoring) VALUES
    (1,  'No major contraindication',        'No clinically significant interaction', 'A1c every 3 months, renal panel annually'),
    (2,  'Active major bleed risk to assess','Dual antithrombotic regimen',           'CBC and bleeding surveillance'),
    (3,  'History review for pancreatitis',  'No severe interaction identified',      'GI tolerance and weight trend'),
    (4,  'Pregnancy contraindication check', 'No major interaction',                  'Serum creatinine and potassium'),
    (5,  'Active infection must be excluded', 'Immunosuppressant additive risk',      'TB/HBV screen and infection monitoring'),
    (6,  'Hepatic disease caution',          'No major interaction',                   'Lipid panel and ALT/AST'),
    (7,  'Long-term PPI risk if chronic use','No major interaction',                   'Symptom control and duration review'),
    (8,  'Peptic ulcer and CKD risk factors','Concomitant NSAID exposure',             'Renal function and GI adverse effects'),
    (9,  'Macrolide QT-risk screening',      'Potential QT-prolonging co-therapy',    'ECG only if cardiac risk present'),
    (10, 'Penicillin allergy screening',     'No major interaction',                   'Weight-based dosing confirmation');

-- PBM Policy (1 per PBM response)
INSERT INTO pbm_policy (pbm_response_id, original_status, alternative_status) VALUES
    (1,  'Preferred generic (Tier 1)',                 'Preferred generic (Tier 1)'),
    (2,  'PA required for non-preferred anticoagulant', 'Preferred alternative covered'),
    (3,  'Step therapy required before GLP-1 coverage', 'Preferred GLP-1 covered with criteria'),
    (4,  'Preferred ACE inhibitor (Tier 1)',           'Preferred ACE inhibitor (Tier 1)'),
    (5,  'Non-preferred biologic; PA + step edit',     'Preferred biologic covered with PA'),
    (6,  'Preferred statin with standard quantity edit','Preferred statin with standard quantity edit'),
    (7,  'Preferred PPI (Tier 1)',                     'Preferred PPI (Tier 1)'),
    (8,  'Quantity/day-supply limit exceeded',          'Preferred NSAID covered within limits'),
    (9,  'Stewardship edit: diagnosis/antibiotic mismatch', 'Alternative covered for coded indication'),
    (10, 'Pediatric dosing validation required',        'Covered after dose/formulation correction');

-- Users (10 records)
INSERT INTO users (username, password_hash, role, is_active) VALUES
    ('doc1',      'pbkdf2:sha256:1000000$salt001$hash001', 'doctor',   1),
    ('doc2',      'pbkdf2:sha256:1000000$salt002$hash002', 'doctor',   1),
    ('doc3',      'pbkdf2:sha256:1000000$salt003$hash003', 'doctor',   1),
    ('doc4',      'pbkdf2:sha256:1000000$salt004$hash004', 'doctor',   0),
    ('pharm1',    'pbkdf2:sha256:1000000$salt005$hash005', 'pharmacist', 1),
    ('pharm2',    'pbkdf2:sha256:1000000$salt006$hash006', 'pharmacist', 1),
    ('pharm3',    'pbkdf2:sha256:1000000$salt007$hash007', 'pharmacist', 1),
    ('pharm4',    'pbkdf2:sha256:1000000$salt008$hash008', 'pharmacist', 0),
    ('pbm1',      'pbkdf2:sha256:1000000$salt009$hash009', 'pbm',      1),
    ('pbm2',      'pbkdf2:sha256:1000000$salt010$hash010', 'pbm',      1);