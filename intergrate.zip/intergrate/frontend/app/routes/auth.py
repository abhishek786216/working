from flask import Blueprint, request, jsonify, current_app
from werkzeug.security import generate_password_hash
import jwt
from datetime import datetime, timedelta
from app.db import get_db_connection
from app.utils import verify_password

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/register', methods=['POST'])
def register():
    data = request.json or {}
    username = (data.get('username') or '').strip()
    password = data.get('password') or ''
    role = (data.get('role') or 'pharmacist').strip().lower()
    allowed_roles = {'pharmacist', 'doctor', 'pbm'}

    if not username or not password:
        return jsonify({'error': 'Username and password are required'}), 400

    if len(password) < 6:
        return jsonify({'error': 'Password must be at least 6 characters'}), 400

    if role not in allowed_roles:
        return jsonify({'error': 'Invalid role. Allowed roles: pharmacist, doctor, pbm'}), 400

    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("SELECT id FROM users WHERE username=?", (username,))
        if cursor.fetchone():
            return jsonify({'error': 'Username already exists'}), 409

        cursor.execute(
            "INSERT INTO users (username, password_hash, role, is_active) VALUES (?, ?, ?, 1)",
            (username, generate_password_hash(password), role)
        )
        conn.commit()
        return jsonify({'message': 'Registration successful. Please login.', 'role': role}), 201
    except Exception as e:
        conn.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        conn.close()


@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.json or {}
    username = data.get('username')
    password = data.get('password')

    if not username or not password:
        return jsonify({'error': 'Username and password are required'}), 400

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM users WHERE username=? AND is_active=1", (username,))
    user = cursor.fetchone()
    conn.close()

    if not user:
        return jsonify({'error': 'Invalid credentials'}), 401

    if not verify_password(user, password):
        return jsonify({'error': 'Invalid credentials'}), 401

    token = jwt.encode({
        'id': user['id'],
        'role': user['role'],
        'exp': datetime.utcnow() + timedelta(hours=2)
    }, current_app.config['SECRET_KEY'], algorithm='HS256')

    return jsonify({"token": token, "role": user["role"], "username": user["username"]})
