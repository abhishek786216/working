from flask import Blueprint, request, jsonify
from datetime import datetime
import random
import importlib
import requests
import os
import config as _config_module          # imported as module so we can reload it
from app.db import get_db_connection
from app.utils import token_required, role_required

prescription_bp = Blueprint('prescription', __name__)

PHASE_LABELS = {
    "DEDUCTIBLE": "Deductible Stage",
    "INITIAL_COVERAGE": "Standard Coverage",
    "CATASTROPHIC": "OOP Max Reached",
}


def _ensure_cost_comparison_columns(cursor):
    """Adds insurance context columns to existing DBs if they are missing."""
    cursor.execute("PRAGMA table_info(pbm_cost_comparison)")
    existing = {row[1] for row in cursor.fetchall()}

    required = {
        "insurance_phase": "TEXT",
        "ytd_oop": "REAL",
        "deductible_cap": "REAL",
        "oop_max_cap": "REAL",
        "deductible_remaining": "REAL",
        "oop_remaining": "REAL",
    }

    for column_name, column_type in required.items():
        if column_name not in existing:
            cursor.execute(f"ALTER TABLE pbm_cost_comparison ADD COLUMN {column_name} {column_type}")


def _to_float(value, default):
    try:
        if value is None or value == "":
            return float(default)
        return float(value)
    except (TypeError, ValueError):
        return float(default)


def _phase_label(phase):
    if not phase:
        return "Standard Coverage"
    return PHASE_LABELS.get(str(phase), str(phase).replace("_", " ").title())


def _normalize_insurance_context(raw_context):
    context = raw_context or {}
    ytd_oop = _to_float(context.get("ytd_oop"), 0.0)
    deductible_cap = _to_float(context.get("deductible_cap"), 750.0)
    oop_max_cap = _to_float(context.get("oop_max_cap"), 3000.0)
    deductible_remaining = _to_float(
        context.get("deductible_remaining"),
        max(deductible_cap - ytd_oop, 0.0),
    )
    oop_remaining = _to_float(
        context.get("oop_remaining"),
        max(oop_max_cap - ytd_oop, 0.0),
    )

    return {
        "phase": _phase_label(context.get("phase")),
        "ytd_oop": round(ytd_oop, 2),
        "deductible_cap": round(deductible_cap, 2),
        "oop_max_cap": round(oop_max_cap, 2),
        "deductible_remaining": round(deductible_remaining, 2),
        "oop_remaining": round(oop_remaining, 2),
    }

# 1. Submit Prescription
@prescription_bp.route('/prescription', methods=['POST'])
@token_required
@role_required(['pharmacist'])
def submit_prescription():
    data = request.json or {}
    
    # Extract fields
    patient_id = data.get('patient_account_id')
    npi_number = data.get('npi_number')
    prod_nm = data.get('prod_nm')
    dosage_size = data.get('dosage_size')
    frequency = data.get('frequency')
    days_supply = data.get('days_supply')
    diagnosis = data.get('diagnosis')
    
    # Auto-generate current date for date_written
    date_written = datetime.now().strftime('%Y-%m-%d')

    # Basic validation
    if not all([patient_id, npi_number, prod_nm, dosage_size, frequency, days_supply, diagnosis]):
        return jsonify({'error': 'Missing required fields'}), 400

    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        # Generate unique RX Number
        cursor.execute("SELECT COUNT(*) FROM prescription")
        count = cursor.fetchone()[0] + 1
        date_str = datetime.now().strftime('%Y%m%d')
        rx_number = f"RX-{date_str}-{count:05d}"

        # Ensure patient exists
        cursor.execute("INSERT OR IGNORE INTO patient (patient_account_id) VALUES (?)", (patient_id,))
        
        # Ensure provider exists
        cursor.execute("INSERT OR IGNORE INTO provider (npi_number) VALUES (?)", (npi_number,))

        # Insert Prescription
        cursor.execute("""
            INSERT INTO prescription (rx_number, patient_account_id, npi_number, prod_nm, dosage_size, frequency, days_supply, rx_status, date_written)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'Submitted', ?)
        """, (rx_number, patient_id, npi_number, prod_nm, dosage_size, frequency, days_supply, date_written))

        # No separate RX tracking table — rely on prescription.rx_status and pbm_response/doctor_decision

        # Call the PBM orchestrator API to process the claim
        call_orchestrator_api(patient_id, prod_nm, diagnosis, days_supply, rx_number, cursor)

        conn.commit()
        return jsonify({'rx_number': rx_number, 'message': 'Prescription submitted successfully'})

    except Exception as e:
        conn.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        conn.close()




def call_orchestrator_api(patient_id, prod_nm, diagnosis, days_supply, rx_number, cursor):
    """
    Call the PBM orchestrator API to process the prescription claim.
    Falls back to random decision if API is unavailable.
    
    Args:
        patient_id: Patient account ID
        prod_nm: Drug name
        diagnosis: Diagnosis code/description  
        days_supply: Days supply for quantity calculation
        rx_number: Prescription number
        cursor: Database cursor for updating tables
    """
    pbm_api_url = os.environ.get("PBM_ORCHESTRATOR_URL", "http://localhost:8000/api/orchestrate")
    
    try:
        # Prepare orchestrator payload
        # Note: In production, this should also resolve member_id, plan_id, and drug_id
        # using the PBM lookup layer. For now, using placeholders.
        payload = {
            "drug_id": prod_nm,  # In production: resolve from drug name via PBM lookup
            "member_id": patient_id,
            "plan_id": "DEFAULT_PLAN",  # In production: resolve from member record via PBM lookup
            "quantity": int(days_supply) if days_supply else 30,
            "fill_date": datetime.now().strftime("%Y-%m-%d"),
            "diagnosis": diagnosis,
        }
        
        response = requests.post(pbm_api_url, json=payload, timeout=30)
        response.raise_for_status()
        orch_result = response.json()
        
        # Extract decision from orchestrator response
        decision_map = {
            "auto_approve": "APPROVED",
            "doctor_review": "ESCALATED", 
            "keep_original": "ESCALATED",
        }
        status = decision_map.get(orch_result.get("decision"), "ESCALATED")
        
        # Extract confidence from combined score or use a default
        summary = orch_result.get("summary", {})
        ai_confidence = summary.get("confidence_score", 0.75)
        
        # Get chosen drug (alternative) or original
        chosen_drug = orch_result.get("chosen_drug", prod_nm)
        reason = orch_result.get("reason", "No reason provided")
        
        # Extract financial info from final_candidates
        recommended_alt = None
        estimated_savings = 0
        insurance_context = {}
        final_candidates = orch_result.get("final_candidates", [])
        if final_candidates:
            # Use first candidate as recommendation
            alt_candidate = final_candidates[0]
            recommended_alt = alt_candidate.get("drug_id", prod_nm)
            fin_summary = alt_candidate.get("financial_summary", {})
            fin_detail = alt_candidate.get("financial", {})
            estimated_savings = fin_summary.get("estimated_savings", 0)
            insurance_context = _normalize_insurance_context(fin_detail.get("insurance_context"))
        else:
            insurance_context = _normalize_insurance_context({})

        _ensure_cost_comparison_columns(cursor)
        
        # ── Insert PBM Response ──────────────────────────────────────────────
        cursor.execute("""
            INSERT INTO pbm_response 
            (rx_number, status, ai_confidence, prescribed_drug, diagnosis, recommended_alt, cost_impact, safety_summary, policy_compliance)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            rx_number,
            status,
            ai_confidence,
            prod_nm,
            diagnosis,
            recommended_alt,
            estimated_savings,
            "Reviewed by multi-agent AI",
            "Checked against formulary"
        ))
        
        pbm_id = cursor.lastrowid
        
        # ── Cost Comparison ──────────────────────────────────────────────────
        orig_price = 1500  # Placeholder; in production would come from pricing lookup
        alt_price = max(0, orig_price - estimated_savings)
        cursor.execute("""
            INSERT INTO pbm_cost_comparison 
            (pbm_response_id, original_tier, original_price, original_copay, alternative_tier, alternative_price, alternative_copay, savings,
             insurance_phase, ytd_oop, deductible_cap, oop_max_cap, deductible_remaining, oop_remaining)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            pbm_id,
            "Tier 3",
            orig_price,
            orig_price * 0.2,
            "Tier 1",
            alt_price,
            alt_price * 0.1,
            estimated_savings,
            insurance_context.get("phase"),
            insurance_context.get("ytd_oop"),
            insurance_context.get("deductible_cap"),
            insurance_context.get("oop_max_cap"),
            insurance_context.get("deductible_remaining"),
            insurance_context.get("oop_remaining"),
        ))
        
        # ── Safety ──────────────────────────────────────────────────────────
        clinical_detail = orch_result.get("clinical_detail", {})
        safety_info = "None detected" if clinical_detail.get("safe", True) else "Contraindications detected"
        cursor.execute("""
            INSERT INTO pbm_safety (pbm_response_id, contraindications, interactions, monitoring)
            VALUES (?, ?, ?, ?)
        """, (pbm_id, safety_info, "Minimal interactions", "Standard monitoring"))
        
        # ── Policy ──────────────────────────────────────────────────────────
        policy_summary = orch_result.get("policy_summary", {})
        policy_decision = policy_summary.get("decision", "pending")
        policy_reason = policy_summary.get("reason", "Review required")
        cursor.execute("""
            INSERT INTO pbm_policy (pbm_response_id, original_status, alternative_status)
            VALUES (?, ?, ?)
        """, (pbm_id, policy_reason, "Covered with review"))
        
        # ── Auto-approve decision ────────────────────────────────────────────
        if status == "APPROVED":
            cursor.execute("""
                INSERT INTO doctor_decision (rx_number, status, reason)
                VALUES (?, ?, ?)
            """, (rx_number, "ACCEPTED", reason))
            cursor.execute("""
                UPDATE prescription SET rx_status = 'Approved' WHERE rx_number = ?
            """, (rx_number,))
        else:
            cursor.execute("""
                UPDATE prescription SET rx_status = 'Pending' WHERE rx_number = ?
            """, (rx_number,))
    
    except requests.exceptions.RequestException as e:
        # API unavailable - fall back to random decision
        print(f"Orchestrator API call failed: {e}. Using fallback decision.")
        fallback_pbm_processing(cursor, rx_number, prod_nm, diagnosis)
    except Exception as e:
        # Unexpected error - fall back to random decision
        print(f"Error processing orchestrator response: {e}. Using fallback decision.")
        fallback_pbm_processing(cursor, rx_number, prod_nm, diagnosis)


def fallback_pbm_processing(cursor, rx_number, drug, diagnosis):
    """
    Fallback two-outcome PBM decision logic when orchestrator is unavailable.
    Used when the orchestrator API is unreachable.
    """
    importlib.reload(_config_module)
    threshold = _config_module.Config.AUTO_APPROVE_THRESHOLD
    ai_conf = round(random.uniform(0.20, 0.97), 2)
    auto_approved = ai_conf >= threshold

    if auto_approved:
        status = 'APPROVED'
        alt = None
        savings = 0
        policy = 'Fully covered'
        alt_policy = 'Fully covered'
    else:
        status = 'ESCALATED'
        alt = f"Preferred alternative for {drug}"
        savings = random.randint(100, 2500)
        policy = 'Prior auth required'
        alt_policy = 'Covered with copay'

    cursor.execute("""
        INSERT INTO pbm_response 
        (rx_number, status, ai_confidence, prescribed_drug, diagnosis, recommended_alt, cost_impact, safety_summary, policy_compliance)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'Reviewed by AI', 'Checked against formulary')
    """, (rx_number, status, ai_conf, drug, diagnosis, alt, savings))

    pbm_id = cursor.lastrowid

    _ensure_cost_comparison_columns(cursor)

    orig_price = random.randint(100, 3000)
    alt_price = max(0, orig_price - savings)
    cursor.execute("""
        INSERT INTO pbm_cost_comparison 
        (pbm_response_id, original_tier, original_price, original_copay, alternative_tier, alternative_price, alternative_copay, savings,
         insurance_phase, ytd_oop, deductible_cap, oop_max_cap, deductible_remaining, oop_remaining)
        VALUES (?, 'Tier 3', ?, ?, 'Tier 1', ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (pbm_id, orig_price, orig_price * 0.2, alt_price, alt_price * 0.1, savings,
            "Standard Coverage", 0.0, 750.0, 3000.0, 750.0, 3000.0))

    cursor.execute("""
        INSERT INTO pbm_safety (pbm_response_id, contraindications, interactions, monitoring)
        VALUES (?, 'None detected', 'Minimal interactions', 'Standard monitoring')
    """, (pbm_id,))

    cursor.execute("""
        INSERT INTO pbm_policy (pbm_response_id, original_status, alternative_status)
        VALUES (?, ?, ?)
    """, (pbm_id, policy, alt_policy))

    if auto_approved:
        cursor.execute("""
            INSERT INTO doctor_decision (rx_number, status, reason)
            VALUES (?, 'ACCEPTED', NULL)
        """, (rx_number,))
        cursor.execute("""
            UPDATE prescription SET rx_status = 'Approved' WHERE rx_number = ?
        """, (rx_number,))
    else:
        cursor.execute("""
            UPDATE prescription SET rx_status = 'Pending' WHERE rx_number = ?
        """, (rx_number,))



# 2. Track Status
@prescription_bp.route('/prescription/<rx_number>/status', methods=['GET'])
@token_required
def get_status(rx_number):
    conn = get_db_connection()
    cursor = conn.cursor()
    # Return simplified status composed from prescription, PBM response and doctor decision
    cursor.execute("SELECT rx_number, rx_status, date_written FROM prescription WHERE rx_number = ?", (rx_number,))
    pres = cursor.fetchone()

    if not pres:
        conn.close()
        return jsonify({'error': 'Prescription not found'}), 404

    # PBM Response
    cursor.execute("SELECT status AS pbm_status, ai_confidence, created_at FROM pbm_response WHERE rx_number = ?", (rx_number,))
    pbm = cursor.fetchone()

    # Doctor Decision
    cursor.execute("SELECT status AS decision_status, reason, created_at FROM doctor_decision WHERE rx_number = ?", (rx_number,))
    decision = cursor.fetchone()

    conn.close()

    # Derive a simple pipeline-style status to keep UI compatibility
    if not pbm:
        status = 'PROCESSING'
        agents_done = []
        agents_pending = ['clinical','financial','pbm']
        estimated_wait_s = 10
        created_at = pres['date_written']
    else:
        if pbm['pbm_status'] == 'ESCALATED' or (decision and not decision['decision_status']):
            status = 'ESCALATED'
            agents_done = ['clinical','financial','pbm']
            agents_pending = ['doctor']
        else:
            status = 'COMPLETED'
            agents_done = ['clinical','financial','pbm']
            agents_pending = []
        estimated_wait_s = 0
        created_at = pbm['created_at']

    response = {
        'rx_number': pres['rx_number'],
        'status': status,
        'prescription_status': pres['rx_status'],
        'date_written': pres['date_written'],
        'agents_done': agents_done,
        'agents_pending': agents_pending,
        'estimated_wait_s': estimated_wait_s,
        'created_at': created_at,
        'pbm_status': pbm['pbm_status'] if pbm else None,
        'ai_confidence': pbm['ai_confidence'] if pbm else None,
        'pbm_created_at': pbm['created_at'] if pbm else None,
        'doctor_decision': dict(decision) if decision else None
    }

    return jsonify(response)


# 3. Get PBM Results
@prescription_bp.route('/prescription/<rx_number>/result', methods=['GET'])
@token_required
def get_results(rx_number):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # PBM Response
    cursor.execute("SELECT * FROM pbm_response WHERE rx_number = ?", (rx_number,))
    pbm = cursor.fetchone()
    
    if not pbm:
        conn.close()
        return jsonify({'pbm': None}) # Not ready yet
        
    pbm_id = pbm['id']
    
    # Sub-objects
    cursor.execute("SELECT * FROM pbm_cost_comparison WHERE pbm_response_id = ?", (pbm_id,))
    cost = cursor.fetchone()
    
    cursor.execute("SELECT * FROM pbm_safety WHERE pbm_response_id = ?", (pbm_id,))
    safety = cursor.fetchone()
    
    cursor.execute("SELECT * FROM pbm_policy WHERE pbm_response_id = ?", (pbm_id,))
    policy = cursor.fetchone()

    # Doctor Decision
    cursor.execute("SELECT * FROM doctor_decision WHERE rx_number = ?", (rx_number,))
    decision = cursor.fetchone()

    conn.close()
    
    return jsonify({
        'pbm': dict(pbm),
        'cost': dict(cost) if cost else None,
        'safety': dict(safety) if safety else None,
        'policy': dict(policy) if policy else None,
        'doctor_decision': dict(decision) if decision else None
    })


# 4. Submit Final Decision
@prescription_bp.route('/prescription/<rx_number>/decision', methods=['POST'])
@token_required
@role_required(['doctor'])
def submit_decision(rx_number):
    data = request.json or {}
    status = data.get('status')
    reason = data.get('reason')

    if status not in ['ACCEPTED', 'REJECTED', 'MODIFIED']:
        return jsonify({'error': 'Invalid status'}), 400

    if status in ['REJECTED', 'MODIFIED'] and not reason:
        return jsonify({'error': 'Reason is required for REJECTED or MODIFIED decisions'}), 400

    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("SELECT rx_number FROM prescription WHERE rx_number = ?", (rx_number,))
        if not cursor.fetchone():
            return jsonify({'error': 'Prescription not found'}), 404

        # Check if decision already exists
        cursor.execute("SELECT id FROM doctor_decision WHERE rx_number = ?", (rx_number,))
        if cursor.fetchone():
            return jsonify({'error': 'Decision already exists for this prescription'}), 400

        cursor.execute("""
            INSERT INTO doctor_decision (rx_number, status, reason)
            VALUES (?, ?, ?)
        """, (rx_number, status, reason))
        
        conn.commit()
        return jsonify({'message': 'Decision saved successfully'})
    except Exception as e:
        conn.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        conn.close()


# 5. Dashboard - All Prescriptions
@prescription_bp.route('/prescriptions', methods=['GET'])
@token_required
@role_required(['pharmacist', 'pbm', 'doctor'])
def list_prescriptions():
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT p.rx_number, p.patient_account_id, p.prod_nm, p.date_written,
               p.rx_status AS tracking_status,
               d.status   AS decision_status,
               pb.status  AS pbm_status
        FROM prescription p
        LEFT JOIN doctor_decision    d  ON p.rx_number = d.rx_number
        LEFT JOIN pbm_response       pb ON p.rx_number = pb.rx_number
        ORDER BY p.date_written DESC, p.rx_number DESC
    """)

    rows = cursor.fetchall()
    conn.close()

    return jsonify([dict(row) for row in rows])
